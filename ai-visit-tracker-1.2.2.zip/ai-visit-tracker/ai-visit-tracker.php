<?php
/**
 * Plugin Name:       AI Visit Tracker
 * Plugin URI:        https://csdigital.ch/
 * Description:       Suivi des crawlers et bots de plateformes (IA, moteurs de recherche, reseaux sociaux) via detection User-Agent. Tableau de bord « Visibilite » (menu de niveau 1) : familles, sources, finalites, top URLs, visibilite par contenu, histogramme. Aucune dependance, autonome et reutilisable.
 * Version:           1.2.2
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            CS Digital
 * Author URI:        https://csdigital.ch/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-visit-tracker
 * Update URI:        https://github.com/CS-Digital-Suisse/ai-visit-tracker-releases
 *
 * @package AI_Visit_Tracker
 *
 * @version 1.2.2
 *
 * @changelog
 * 1.2.2 : Regroupement des URLs par chemin dans toutes les listes (top URLs
 *          dashboard et details source/contenu/finalite, export CSV). Chaque
 *          ligne represente desormais un chemin (/page/) et non une URL complete
 *          avec parametres. KPI "pages distinctes" passe a COUNT(DISTINCT
 *          path_hash). Nouvelle vue detail_path : KPIs total/variantes, courbe
 *          temporelle, repartition source et finalite, panneau "Repartition par
 *          parametre" (decomposition par cle=valeur en PHP), table paginee des
 *          variantes liant vers la vue detail_url (journal exact inchange).
 *          Neutralisation des jetons de clic a la capture : gclid, fbclid,
 *          msclkid, dclid, gbraid, wbraid voient leur valeur videe (cle conservee,
 *          ordre preserve), les utm_* et autres parametres sont conserves tels
 *          quels. Constante CLICK_ID_PARAMS. Migration additive 1.6 : ajout des
 *          colonnes path/path_hash et index idx_path sur aivt_urls, backfill
 *          SUBSTRING_INDEX idempotent par lots, aucune perte de donnees. Purge
 *          par chemin (nouvelle cible 'path') depuis la vue detail_path. La vue
 *          detail_url (journal exact d'une variante) reste inchangee.
 *
 * 1.2.1 : Courbe d'evolution dans le temps ajoutee a chaque vue detail (URL,
 *          source, contenu, finalite). Coherente avec les filtres et la periode
 *          de la vue (memes conditions WHERE que les KPIs). Vue URL : couvre
 *          tout l'historique de l'URL, borne a 365 barres. Vues source/contenu/
 *          finalite : respectent le selecteur de periode, borne a 365 barres en
 *          mode tout. Helper prive get_histogram_series() partage entre le
 *          dashboard et les vues detail (pas de duplication). get_histogram()
 *          inchange : resultats strictement identiques. render_chart() reutilise
 *          tel quel. Zero changement de schema (DB_VERSION inchangee).
 *
 * 1.2.0 : Optimisation du stockage par deduplication des URLs et User-Agents
 *          dans deux tables de reference (aivt_urls, aivt_user_agents). Division
 *          du poids par visite par 3 a 4 (de ~400-500 octets a ~120-150, index
 *          compris). Migration DB 1.5 idempotente, reprenable, par lots de 20 000
 *          lignes avec borne de temps (~10 s/appel). Verification d'integrite
 *          (COUNT(*) WHERE url_id IS NULL = 0 et ua_id IS NULL = 0) avant toute
 *          suppression des colonnes transitoires. Identifiant public url_hash
 *          (hexadecimal 40) conserve inchange. Zero changement fonctionnel.
 *
 * 1.1.1 : Reflet total complete : le panneau Familles respecte aussi le filtre
 *          source actif (get_family_breakdown transmet la source).
 *
 * 1.1.0 : Extension du perimetre a toutes les plateformes grand public : reseaux
 *          sociaux (facebookexternalhit, Twitterbot, LinkedInBot, Pinterestbot,
 *          WhatsApp, Slackbot) et moteurs supplementaires (YandexBot, Baiduspider,
 *          SeznamBot). Nouvelle finalite 'social' (Partage social). Dimension
 *          famille de plateforme (ia / search / social) : constantes SOURCE_FAMILIES,
 *          FAMILY_LABELS, FAMILY_COLORS, filtre 3e select, panneau Familles avant
 *          Finalites, propagation detail et export. Menu et UI renommes
 *          « Visibilite » (generalisation des textes).
 *
 * 1.0.6 : Image d'extension pour l'UI des mises a jour WordPress (assets/img/icon.svg,
 *          badge violet, cle 'icons' dans inject_update_info). Retour de l'icone
 *          de menu simple (SVG CPU gris #a7aaad, identique 1.0.4).
 *
 * 1.0.5 : Icone de menu : badge violet de la marque (degrade #6366f1 -> #8b5cf6,
 *          coins arrondis, motif CPU blanc centre) a la place du CPU gris.
 *
 * 1.0.4 : Correction de la verification manuelle : delete_site_transient
 *          avant wp_update_plugins() contourne le throttle 12 h de WP et
 *          affiche la banniere native « Mettre a jour maintenant ». Auto-update
 *          inscrit dans l'option native auto_update_plugins (via
 *          maybe_optin_auto_update) pour que la colonne UI reflète l'etat
 *          reel et affiche le decompte avant la prochaine mise a jour planifiee.
 *
 * 1.0.3 : Accent restaure dans le libelle du menu (« Visibilité IA »).
 *
 * 1.0.2 : Page d'admin passee en menu de niveau 1 (entree « Visibilite IA »)
 *          au lieu du sous-menu Outils. Hook toplevel_page_, URLs admin.php.
 *
 * 1.0.1 : Updater distant natif WordPress. Lecture du manifest latest.json
 *          depuis le repo public GitHub (transient 12 h, sentinelle 1 h en
 *          cas d'echec). Injection dans pre_set_site_transient_update_plugins,
 *          auto-update active par defaut, lien « Verifier les mises a jour »
 *          dans la liste des extensions, notice admin native apres verification.
 *          Update URI: dans l'entete du plugin (WP 5.8+). DB_VERSION inchangee.
 *
 * 1.0.0 : Premiere version stable. Plugin autonome de suivi des crawlers IA,
 *          généralisé depuis le tracker du thème « Une Autre Voix » et rendu
 *          non spécifique à un site (labels de contenu génériques, WooCommerce
 *          facultatif). Table custom {prefix}aivt_visits, page admin
 *          « Visibilite IA » avec interface moderne : topbar, cartes KPI
 *          animées, graphique d'activité, classements à barres par moteur d'IA
 *          et par type de contenu, table d'URLs custom, vues détail dédiées
 *          (URL, source, type de contenu) à en-tête sombre. Design system CSS
 *          autonome + JS vanilla (count-up, lignes cliquables), zéro dépendance.
 *          Distinction des fichiers techniques (assets CSS/JS/images/polices/
 *          médias) via la colonne is_asset : exclus par défaut des statistiques,
 *          réintégrables via une bascule, catégorie dédiée consultable.
 *          Finalité (entraînement / indexation / fetch utilisateur / agent)
 *          comme dimension à part entière : panneau, filtre, page dédiée et
 *          ventilation dans les vues détail ; faceting source x finalité.
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AIVT_VERSION', '1.2.2' );
define( 'AIVT_PLUGIN_FILE', __FILE__ );
define( 'AIVT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIVT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once AIVT_PLUGIN_DIR . 'includes/class-ai-visit-tracker.php';

/**
 * Crée / met à jour le schéma de la table à l'activation du plugin.
 * Planifie aussi le cron de rafraichissement des plages IP si absent.
 *
 * maybe_install_table() est idempotent (compare la version stockée), donc
 * sûr à rappeler. Le hook 'init' du tracker assure aussi la migration sur
 * les sites où le plugin serait mis à jour sans réactivation.
 *
 * @return void
 */
function aivt_activate() {
	AIVT_Tracker::get_instance()->maybe_install_table();
	if ( ! wp_next_scheduled( 'aivt_refresh_ip_ranges' ) ) {
		wp_schedule_event( time(), 'weekly', 'aivt_refresh_ip_ranges' );
	}
}
register_activation_hook( __FILE__, 'aivt_activate' );

/**
 * Déplanifie le cron de rafraichissement des plages IP à la désactivation.
 *
 * @return void
 */
function aivt_deactivate() {
	$timestamp = wp_next_scheduled( 'aivt_refresh_ip_ranges' );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'aivt_refresh_ip_ranges' );
	}
}
register_deactivation_hook( __FILE__, 'aivt_deactivate' );

/**
 * Initialise le tracker (Singleton). Le constructeur enregistre tous les
 * hooks (capture, page admin, purge, assets).
 *
 * @return void
 */
function aivt_bootstrap() {
	AIVT_Tracker::get_instance();
}
add_action( 'plugins_loaded', 'aivt_bootstrap' );
