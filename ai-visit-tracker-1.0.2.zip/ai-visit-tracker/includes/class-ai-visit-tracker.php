<?php
/**
 * AI Visit Tracker : Classe principale
 *
 * Suivi des CRAWLERS IA visitant le site (détection via User-Agent).
 * Ex : GPTBot, ClaudeBot, PerplexityBot, Google-Extended…
 *
 * Les visites non IA ne sont PAS loggées (la table reste focalisée).
 *
 * Stockage : table custom {prefix}aivt_visits.
 * Capture  : template_redirect priorité 999 (après d'éventuels set_404 tardifs).
 * Admin    : Visibilite IA (menu de niveau 1, capability manage_options).
 *
 * Note RGPD : stockage d'IP + User-Agent. Mettre à jour la politique de
 * confidentialité (base légale : intérêt légitime : analyse SEO/visibilité).
 *
 * @package  AI_Visit_Tracker
 * @license  GPL-2.0-or-later
 * @version  1.0.2
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracker des visites IA.
 *
 * @since 0.1.0
 */
class AIVT_Tracker {

	/** @var string Version du schéma de table. */
	const DB_VERSION = '1.4';

	/** @var string Option WP qui mémorise la version installée. */
	const DB_VERSION_OPTION = 'aivt_db_version';

	/** @var string Suffixe de la table (préfixé par $wpdb->prefix). */
	const TABLE_SUFFIX = 'aivt_visits';

	/** @var string Slug de la page d'admin. */
	const ADMIN_SLUG = 'ai-visit-tracker';

	/** @var string URL du manifest de mise a jour (repo public). */
	const MANIFEST_URL = 'https://raw.githubusercontent.com/CS-Digital-Suisse/ai-visit-tracker-releases/main/latest.json';

	/** @var string Cle du transient de mise en cache du manifest. */
	const UPDATE_CACHE_KEY = 'aivt_update_manifest';

	/**
	 * Définitions des bots IA détectables par User-Agent.
	 *
	 * Ordre : du PLUS spécifique au PLUS générique. Le premier match gagne.
	 * (Ex : Applebot-Extended doit être testé AVANT Applebot.)
	 *
	 * @var array<int,array{label:string,source:string,purpose:string,regex:string}>
	 */
	const BOT_DEFINITIONS = array(
		// OpenAI
		array( 'label' => 'OAI-SearchBot',         'source' => 'openai',      'purpose' => 'search',     'regex' => '/OAI-SearchBot/i' ),
		array( 'label' => 'ChatGPT-User',          'source' => 'openai',      'purpose' => 'user-fetch', 'regex' => '/ChatGPT-User/i' ),
		array( 'label' => 'GPTBot',                'source' => 'openai',      'purpose' => 'training',   'regex' => '/GPTBot/i' ),

		// Anthropic
		array( 'label' => 'Claude-SearchBot',      'source' => 'anthropic',   'purpose' => 'search',     'regex' => '/Claude-SearchBot/i' ),
		array( 'label' => 'Claude-User',           'source' => 'anthropic',   'purpose' => 'user-fetch', 'regex' => '/Claude-User/i' ),
		array( 'label' => 'ClaudeBot',             'source' => 'anthropic',   'purpose' => 'training',   'regex' => '/ClaudeBot/i' ),
		array( 'label' => 'claude-web',            'source' => 'anthropic',   'purpose' => 'training',   'regex' => '/claude-web/i' ),
		array( 'label' => 'anthropic-ai',          'source' => 'anthropic',   'purpose' => 'training',   'regex' => '/anthropic-ai/i' ),

		// Google (recherche + IA + agentique + publicité + service technique).
		// Tokens robots.txt SANS requete (exclus, jamais detectables) : Googlebot-News, Google-Extended.
		array( 'label' => 'Google-CloudVertexBot',    'source' => 'google', 'purpose' => 'agentic',    'regex' => '/Google-CloudVertexBot/i' ),
		array( 'label' => 'Google-NotebookLM',        'source' => 'google', 'purpose' => 'user-fetch', 'regex' => '/Google-NotebookLM/i' ),
		array( 'label' => 'Google-Read-Aloud',        'source' => 'google', 'purpose' => 'user-fetch', 'regex' => '/Google-Read-Aloud/i' ),
		array( 'label' => 'Google-Agent',             'source' => 'google', 'purpose' => 'agentic',    'regex' => '/Google-Agent/i' ),
		array( 'label' => 'Google-InspectionTool',    'source' => 'google', 'purpose' => 'ops',        'regex' => '/Google-InspectionTool/i' ),
		array( 'label' => 'Google-Safety',            'source' => 'google', 'purpose' => 'ops',        'regex' => '/Google-Safety/i' ),
		array( 'label' => 'Google-Site-Verification', 'source' => 'google', 'purpose' => 'ops',        'regex' => '/Google-Site-Verification/i' ),
		array( 'label' => 'Google-Pinpoint',          'source' => 'google', 'purpose' => 'user-fetch', 'regex' => '/Google-Pinpoint/i' ),
		array( 'label' => 'Google-CWS',               'source' => 'google', 'purpose' => 'ops',        'regex' => '/Google-CWS/i' ),
		array( 'label' => 'GoogleProducer',           'source' => 'google', 'purpose' => 'ops',        'regex' => '/GoogleProducer/i' ),
		array( 'label' => 'GoogleMessages',           'source' => 'google', 'purpose' => 'ops',        'regex' => '/GoogleMessages/i' ),
		array( 'label' => 'APIs-Google',              'source' => 'google', 'purpose' => 'ops',        'regex' => '/APIs-Google/i' ),
		array( 'label' => 'FeedFetcher-Google',       'source' => 'google', 'purpose' => 'ops',        'regex' => '/FeedFetcher-Google/i' ),
		array( 'label' => 'Mediapartners-Google',     'source' => 'google', 'purpose' => 'ads',        'regex' => '/Mediapartners-Google/i' ),
		array( 'label' => 'AdsBot-Google-Mobile',     'source' => 'google', 'purpose' => 'ads',        'regex' => '/AdsBot-Google-Mobile/i' ),
		array( 'label' => 'AdsBot-Google',            'source' => 'google', 'purpose' => 'ads',        'regex' => '/AdsBot-Google/i' ),
		array( 'label' => 'Storebot-Google',          'source' => 'google', 'purpose' => 'search',     'regex' => '/Storebot-Google/i' ),
		array( 'label' => 'GoogleOther-Image',        'source' => 'google', 'purpose' => 'training',   'regex' => '/GoogleOther-Image/i' ),
		array( 'label' => 'GoogleOther-Video',        'source' => 'google', 'purpose' => 'training',   'regex' => '/GoogleOther-Video/i' ),
		array( 'label' => 'GoogleOther',              'source' => 'google', 'purpose' => 'training',   'regex' => '/GoogleOther/i' ),
		array( 'label' => 'Googlebot-Image',          'source' => 'google', 'purpose' => 'search',     'regex' => '/Googlebot-Image/i' ),
		array( 'label' => 'Googlebot-Video',          'source' => 'google', 'purpose' => 'search',     'regex' => '/Googlebot-Video/i' ),
		array( 'label' => 'Googlebot',                'source' => 'google', 'purpose' => 'search',     'regex' => '/Googlebot/i' ),

		// Perplexity
		array( 'label' => 'PerplexityBot',         'source' => 'perplexity',  'purpose' => 'search',     'regex' => '/PerplexityBot/i' ),
		array( 'label' => 'Perplexity-User',       'source' => 'perplexity',  'purpose' => 'user-fetch', 'regex' => '/Perplexity-User/i' ),

		// Mistral
		array( 'label' => 'MistralAI-User',        'source' => 'mistral',     'purpose' => 'user-fetch', 'regex' => '/MistralAI-User/i' ),

		// Meta
		array( 'label' => 'meta-externalagent',    'source' => 'meta',        'purpose' => 'training',   'regex' => '/meta-externalagent/i' ),
		array( 'label' => 'meta-externalfetcher',  'source' => 'meta',        'purpose' => 'user-fetch', 'regex' => '/meta-externalfetcher/i' ),
		array( 'label' => 'FacebookBot',           'source' => 'meta',        'purpose' => 'training',   'regex' => '/FacebookBot/i' ),

		// Apple (Applebot-Extended est un jeton robots.txt, pas un crawler : exclu)
		array( 'label' => 'Applebot',              'source' => 'apple',       'purpose' => 'search',     'regex' => '/Applebot/i' ),

		// Microsoft / Bing (doc : bing.com/webmasters/help/which-crawlers-does-bing-use-8c184ec0)
		// Tokens specifiques AVANT bingbot generique.
		array( 'label' => 'BingPreview',           'source' => 'microsoft',   'purpose' => 'ops',        'regex' => '/BingPreview/i' ),
		array( 'label' => 'adidxbot',              'source' => 'microsoft',   'purpose' => 'ads',        'regex' => '/adidxbot/i' ),
		array( 'label' => 'bingbot',               'source' => 'microsoft',   'purpose' => 'search',     'regex' => '/bingbot/i' ),

		// DuckDuckGo (doc : duckduckgo.com/duckduckgo-help-pages/results/duckduckbot)
		// DuckDuckBot AVANT DuckAssistBot car les deux contiennent "Duck" mais
		// "DuckDuckBot" est plus specifique que "DuckAssistBot".
		array( 'label' => 'DuckDuckBot',           'source' => 'duckduckgo',  'purpose' => 'search',     'regex' => '/DuckDuckBot/i' ),

		// Autres
		array( 'label' => 'Bytespider',            'source' => 'bytedance',   'purpose' => 'training',   'regex' => '/Bytespider/i' ),
		array( 'label' => 'Amazonbot',             'source' => 'amazon',      'purpose' => 'search',     'regex' => '/Amazonbot/i' ),
		array( 'label' => 'DuckAssistBot',         'source' => 'duckduckgo',  'purpose' => 'search',     'regex' => '/DuckAssistBot/i' ),
		array( 'label' => 'cohere-ai',             'source' => 'cohere',      'purpose' => 'training',   'regex' => '/cohere-(ai|training-data-crawler)/i' ),
		array( 'label' => 'YouBot',                'source' => 'you',         'purpose' => 'search',     'regex' => '/YouBot/i' ),
		array( 'label' => 'CCBot',                 'source' => 'commoncrawl', 'purpose' => 'training',   'regex' => '/CCBot/i' ),
	);

	/**
	 * Libellés d'affichage des sources canoniques.
	 *
	 * @var array<string,string>
	 */
	const SOURCE_LABELS = array(
		'openai'      => 'OpenAI',
		'anthropic'   => 'Anthropic',
		'google'      => 'Google',
		'perplexity'  => 'Perplexity',
		'mistral'     => 'Mistral AI',
		'meta'        => 'Meta',
		'apple'       => 'Apple',
		'microsoft'   => 'Microsoft',
		'bytedance'   => 'ByteDance',
		'amazon'      => 'Amazon',
		'duckduckgo'  => 'DuckDuckGo',
		'cohere'      => 'Cohere',
		'you'         => 'You.com',
		'phind'       => 'Phind',
		'poe'         => 'Poe',
		'kagi'        => 'Kagi',
		'xai'         => 'xAI',
		'commoncrawl' => 'Common Crawl',
	);

	/**
	 * Libellés d'affichage des purposes.
	 *
	 * @var array<string,string>
	 */
	const PURPOSE_LABELS = array(
		'training'   => 'Entraînement',
		'search'     => 'Indexation',
		'user-fetch' => 'Fetch utilisateur',
		'agentic'    => 'Agent IA',
		'ads'        => 'Publicité',
		'ops'        => 'Service technique',
	);

	/**
	 * Libellés d'affichage des content_types détectés.
	 *
	 * @var array<string,string>
	 */
	const CONTENT_TYPE_LABELS = array(
		'home'             => 'Accueil',
		'product'          => 'Produit',
		'post'             => 'Article',
		'page'             => 'Page',
		'author'           => 'Auteur',
		'shop_archive'     => 'Boutique',
		'product_category' => 'Catégorie de produits',
		'category'         => 'Catégorie',
		'archive'          => 'Archive',
		'404'              => '404',
		'other'            => 'Autre',
		// Catégorie virtuelle : jamais produite par detect_content(), utilisée
		// uniquement comme libellé / cible de filtre pour la colonne is_asset.
		'asset'            => 'Fichiers techniques',
	);

	/**
	 * Couleur d'accent de marque par source IA (pastilles, barres).
	 * Fallback sur l'accent du thème UI si la source est inconnue.
	 *
	 * @var array<string,string>
	 */
	const SOURCE_COLORS = array(
		'openai'      => '#10a37f',
		'anthropic'   => '#cc785c',
		'google'      => '#4285f4',
		'perplexity'  => '#20808d',
		'mistral'     => '#fa520f',
		'meta'        => '#0866ff',
		'apple'       => '#1d1d1f',
		'microsoft'   => '#00a4ef',
		'bytedance'   => '#fe2c55',
		'amazon'      => '#ff9900',
		'duckduckgo'  => '#de5833',
		'cohere'      => '#ff7759',
		'you'         => '#5b51e0',
		'phind'       => '#3b82f6',
		'poe'         => '#5d5dff',
		'kagi'        => '#ffb319',
		'xai'         => '#111111',
		'commoncrawl' => '#0a6cff',
	);

	/**
	 * Nom d'icône (cf. self::icon()) par type de contenu.
	 *
	 * @var array<string,string>
	 */
	const CONTENT_TYPE_ICONS = array(
		'home'             => 'home',
		'product'          => 'tag',
		'post'             => 'doc',
		'page'             => 'page',
		'author'           => 'user',
		'shop_archive'     => 'grid',
		'product_category' => 'grid',
		'category'         => 'folder',
		'archive'          => 'archive',
		'404'              => 'alert',
		'other'            => 'dot',
		'asset'            => 'code',
	);

	/**
	 * Tonalité (suffixe de classe CSS .aivt-badge-*) par finalité de crawl.
	 *
	 * @var array<string,string>
	 */
	const PURPOSE_TONES = array(
		'training'   => 'training',
		'search'     => 'search',
		'user-fetch' => 'user-fetch',
		'agentic'    => 'agentic',
	);

	/**
	 * Couleur d'accent par finalité (pastilles / barres du classement),
	 * alignée sur les badges. Fallback sur l'accent UI si inconnue.
	 *
	 * @var array<string,string>
	 */
	const PURPOSE_COLORS = array(
		'training'   => '#d98324',
		'search'     => '#2f74e0',
		'user-fetch' => '#0f9d6b',
		'agentic'    => '#7c5cff',
		'ads'        => '#e0568a',
		'ops'        => '#64748b',
	);

	/**
	 * Extensions considérées comme « fichiers techniques » (assets), par
	 * opposition au contenu. Sert à la détection (is_asset) et au backfill.
	 *
	 * Volontairement SANS .xml / .txt / .pdf / .json : sitemaps, robots.txt,
	 * llms.txt et PDF ont un intérêt SEO et restent classés comme contenu.
	 *
	 * @var array<int,string>
	 */
	const ASSET_EXTENSIONS = array(
		'css', 'js', 'mjs', 'map',
		'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'avif', 'ico', 'bmp',
		'woff', 'woff2', 'ttf', 'eot', 'otf',
		'mp4', 'webm', 'ogg', 'mp3', 'wav', 'm4a',
	);

	/** @var AIVT_Tracker|null */
	private static $instance = null;

	/**
	 * Obtenir l'instance unique.
	 *
	 * @return AIVT_Tracker
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructeur (Singleton).
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'maybe_install_table' ), 5 );
		// Priorité 999 : on capture après tout le monde (notamment d'éventuels
		// set_404() tardifs qui changeraient le content_type sinon).
		add_action( 'template_redirect', array( $this, 'capture_visit' ), 999 );
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
		add_action( 'admin_post_aivt_purge', array( $this, 'handle_purge' ) );
		add_action( 'admin_post_aivt_export', array( $this, 'handle_export' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'aivt_refresh_ip_ranges', array( $this, 'refresh_ip_ranges' ) );
		// Updater distant : injection dans le mecanisme natif WP.
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update_info' ) );
		add_filter( 'auto_update_plugin', array( $this, 'enable_auto_update' ), 10, 2 );
		// Lien « Verifier les mises a jour » dans la liste des extensions.
		$basename = plugin_basename( AIVT_PLUGIN_FILE );
		add_filter( 'plugin_action_links_' . $basename, array( $this, 'add_check_update_link' ) );
		add_action( 'admin_post_aivt_check_update', array( $this, 'handle_check_update' ) );
		add_action( 'admin_notices', array( $this, 'render_update_notice' ) );
	}

	/**
	 * Retourne le nom complet de la table.
	 *
	 * @return string
	 */
	private function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_SUFFIX;
	}

	/**
	 * Crée ou met à jour le schéma de la table si nécessaire.
	 *
	 * @return void
	 */
	public function maybe_install_table() {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}

		global $wpdb;
		$table           = $this->get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			url VARCHAR(500) NOT NULL,
			url_hash CHAR(40) NOT NULL,
			visit_at DATETIME NOT NULL,
			visit_type VARCHAR(16) NOT NULL,
			ai_source VARCHAR(32) NOT NULL,
			ai_label VARCHAR(64) NOT NULL,
			ai_purpose VARCHAR(32) NOT NULL,
			content_type VARCHAR(32) DEFAULT NULL,
			object_id BIGINT UNSIGNED DEFAULT NULL,
			is_asset TINYINT(1) NOT NULL DEFAULT 0,
			verified TINYINT(1) DEFAULT NULL,
			ip VARCHAR(45) DEFAULT NULL,
			user_agent VARCHAR(500) DEFAULT NULL,
			referrer VARCHAR(500) DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY idx_visit_at (visit_at),
			KEY idx_source_visit (ai_source, visit_at),
			KEY idx_url_hash (url_hash),
			KEY idx_visit_url (visit_at, url_hash),
			KEY idx_content (content_type, object_id),
			KEY idx_asset (is_asset, visit_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		// Backfill is_asset pour les lignes déjà enregistrées (idempotent) :
		// marque comme technique toute URL se terminant par une extension d'asset.
		// [.] et [?] = classes pour un point / point d'interrogation littéraux,
		// évite tout souci d'échappement de backslash dans la string SQL.
		$asset_regex = '[.](' . implode( '|', self::ASSET_EXTENSIONS ) . ')([?]|$)';
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$table} SET is_asset = 1 WHERE is_asset = 0 AND LOWER(url) REGEXP %s",
			$asset_regex
		) );

		// Backfill finalité (idempotent) : Google-CloudVertexBot était classé
		// 'training' à tort ; il s'agit d'un crawl agentique (Vertex AI Agents).
		// On réaligne les lignes déjà enregistrées sur la classification corrigée.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			$table,
			array( 'ai_purpose' => 'agentic' ),
			array( 'ai_label' => 'Google-CloudVertexBot' ),
			array( '%s' ),
			array( '%s' )
		);

		// dbDelta n'enlève pas les index qui ne sont plus déclarés ; on supprime
		// idx_type_visit manuellement (devenu inutile depuis 0.3.0 où visit_type
		// vaut toujours 'bot').
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$has_old_index = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
			DB_NAME,
			$table,
			'idx_type_visit'
		) );
		if ( $has_old_index > 0 ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$wpdb->query( "ALTER TABLE {$table} DROP INDEX idx_type_visit" );
		}

		// autoload true : 3 octets, evite une requete SQL a chaque page vue front.
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, true );
	}

	/**
	 * Capture côté serveur les bots IA (détection User-Agent).
	 *
	 * @return void
	 */
	public function capture_visit() {
		// GET et HEAD uniquement (certains scrapers IA testent l'existence
		// d'une URL en HEAD avant de faire un GET ; on les compte aussi).
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : '';
		if ( 'GET' !== $method && 'HEAD' !== $method ) {
			return;
		}
		if ( ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
			( defined( 'REST_REQUEST' ) && REST_REQUEST ) ||
			( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		$user_agent = mb_substr( $user_agent, 0, 500 );

		$classification = $this->classify_bot( $user_agent );
		if ( null === $classification ) {
			return;
		}

		$referrer = isset( $_SERVER['HTTP_REFERER'] ) ? (string) $_SERVER['HTTP_REFERER'] : '';
		$referrer = mb_substr( esc_url_raw( $referrer ), 0, 500 );

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		$request_uri = trim( $request_uri );
		if ( '' === $request_uri ) {
			$request_uri = '/';
		}
		$url      = mb_substr( $request_uri, 0, 500 );
		$url_hash = sha1( $url );

		$content = $this->detect_content();
		$ip      = $this->get_client_ip();
		$now     = current_time( 'mysql' );

		$data = array(
			'url'          => $url,
			'url_hash'     => $url_hash,
			'visit_at'     => $now,
			'visit_type'   => $method,
			'ai_source'    => $classification['source'],
			'ai_label'     => $classification['label'],
			'ai_purpose'   => $classification['purpose'],
			'content_type' => $content['type'],
			'is_asset'     => $this->is_asset_url( $request_uri ),
			'ip'           => $ip,
			'user_agent'   => $user_agent,
			'referrer'     => $referrer,
		);
		$format = array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' );

		// object_id : on ajoute la colonne uniquement si > 0. Sinon, le DEFAULT
		// NULL de la colonne s'applique : sémantiquement plus correct que 0
		// pour les pages sans objet associé (home, archive, 404…).
		if ( $content['object_id'] > 0 ) {
			$data['object_id'] = (int) $content['object_id'];
			$format[]          = '%d';
		}

		// verified : calculé seulement si des plages existent pour cette source.
		// La lecture de l'option ne se fait que pour les hits déjà classés bot.
		$ranges = $this->get_ip_ranges_for_source( $classification['source'] );
		if ( ! empty( $ranges ) ) {
			$data['verified'] = $this->ip_in_any_cidr( $ip, $ranges ) ? 1 : 0;
			$format[]         = '%d';
		}
		// Si pas de plages : on n'insere pas la colonne -> DEFAULT NULL s'applique.

		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert( $this->get_table_name(), $data, $format );
	}

	/**
	 * Classifie un User-Agent comme bot IA connu.
	 *
	 * @param string $user_agent
	 * @return array{label:string,source:string,purpose:string}|null
	 */
	private function classify_bot( $user_agent ) {
		if ( '' === $user_agent ) {
			return null;
		}
		foreach ( self::BOT_DEFINITIONS as $def ) {
			if ( preg_match( $def['regex'], $user_agent ) ) {
				return array(
					'label'   => $def['label'],
					'source'  => $def['source'],
					'purpose' => $def['purpose'],
				);
			}
		}
		return null;
	}

	/**
	 * Détecte le type de contenu de la page courante (produit, article…).
	 *
	 * Convention : object_id = 0 quand pas d'objet associé (home, archive,
	 * 404). capture_visit() le traduit ensuite en NULL en base.
	 *
	 * @return array{type:string,object_id:int}
	 */
	private function detect_content() {
		if ( is_404() ) {
			return array( 'type' => '404', 'object_id' => 0 );
		}
		if ( is_singular( 'product' ) ) {
			return array( 'type' => 'product', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_singular( 'post' ) ) {
			return array( 'type' => 'post', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_page() ) {
			return array( 'type' => 'page', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_author() ) {
			return array( 'type' => 'author', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_post_type_archive( 'product' ) ) {
			return array( 'type' => 'shop_archive', 'object_id' => 0 );
		}
		if ( is_tax( 'product_cat' ) ) {
			return array( 'type' => 'product_category', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_category() ) {
			return array( 'type' => 'category', 'object_id' => (int) get_queried_object_id() );
		}
		if ( is_archive() ) {
			return array( 'type' => 'archive', 'object_id' => 0 );
		}
		if ( is_home() || is_front_page() ) {
			return array( 'type' => 'home', 'object_id' => 0 );
		}
		return array( 'type' => 'other', 'object_id' => 0 );
	}

	/**
	 * Détermine l'IP réelle du client.
	 *
	 * @return string
	 */
	private function get_client_ip() {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		$remote = preg_replace( '/[^a-fA-F0-9:.]/', '', $remote );
		$remote = substr( $remote, 0, 45 );

		// CF-Connecting-IP est accepte UNIQUEMENT si REMOTE_ADDR appartient aux
		// plages Cloudflare officielles. Sinon : REMOTE_ADDR (comportement sur).
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$cf_ranges = $this->get_ip_ranges_for_source( 'cloudflare' );
			if ( ! empty( $cf_ranges ) && $this->ip_in_any_cidr( $remote, $cf_ranges ) ) {
				$ip = (string) $_SERVER['HTTP_CF_CONNECTING_IP'];
				$ip = preg_replace( '/[^a-fA-F0-9:.]/', '', $ip );
				return substr( $ip, 0, 45 );
			}
		}

		return $remote;
	}

	/**
	 * Rafraichit les plages IP officielles depuis les endpoints editeurs.
	 *
	 * Appelé par le cron hebdomadaire et en auto-réparation admin.
	 * En cas d'échec de fetch d'une source : conserve les plages precedentes.
	 *
	 * @return void
	 */
	public function refresh_ip_ranges() {
		$stored = get_option( 'aivt_ip_ranges', array() );
		// Le fallback en cas d'echec de fetch se fait par endpoint : on lit donc
		// le detail par endpoint stocke au refresh precedent ('endpoints'), pas
		// les groupes fusionnes ('sources').
		$prev        = isset( $stored['endpoints'] ) ? (array) $stored['endpoints'] : array();
		$prev_merged = isset( $stored['sources'] ) ? (array) $stored['sources'] : array();

		// Endpoints documentes et verifies dans les docs officielles editeurs.
		$sources = array(
			'google_common'    => array(
				'url'    => 'https://developers.google.com/static/search/apis/ipranges/googlebot.json',
				'format' => 'google',
			),
			'google_special'   => array(
				'url'    => 'https://developers.google.com/static/search/apis/ipranges/special-crawlers.json',
				'format' => 'google',
			),
			'google_triggered' => array(
				'url'    => 'https://developers.google.com/static/search/apis/ipranges/user-triggered-fetchers.json',
				'format' => 'google',
			),
			'google_triggered2' => array(
				'url'    => 'https://developers.google.com/static/search/apis/ipranges/user-triggered-fetchers-google.json',
				'format' => 'google',
			),
			'openai_gptbot'    => array(
				'url'    => 'https://openai.com/gptbot.json',
				'format' => 'google',
			),
			'openai_searchbot' => array(
				'url'    => 'https://openai.com/searchbot.json',
				'format' => 'google',
			),
			'openai_chatgpt'   => array(
				'url'    => 'https://openai.com/chatgpt-user.json',
				'format' => 'google',
			),
			'perplexity_bot'   => array(
				'url'    => 'https://www.perplexity.ai/perplexitybot.json',
				'format' => 'google',
			),
			'perplexity_user'  => array(
				'url'    => 'https://www.perplexity.ai/perplexity-user.json',
				'format' => 'google',
			),
			'cloudflare_v4'    => array(
				'url'    => 'https://www.cloudflare.com/ips-v4',
				'format' => 'text',
			),
			'cloudflare_v6'    => array(
				'url'    => 'https://www.cloudflare.com/ips-v6',
				'format' => 'text',
			),
		);

		$new_sources = array();
		foreach ( $sources as $key => $cfg ) {
			$resp = wp_remote_get( $cfg['url'], array( 'timeout' => 5 ) );
			if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
				// Conserver les plages precedentes en cas d'echec.
				if ( isset( $prev[ $key ] ) ) {
					$new_sources[ $key ] = $prev[ $key ];
				}
				continue;
			}
			$body   = (string) wp_remote_retrieve_body( $resp );
			$ranges = array();
			if ( 'google' === $cfg['format'] ) {
				$decoded = json_decode( $body, true );
				if ( ! empty( $decoded['prefixes'] ) && is_array( $decoded['prefixes'] ) ) {
					foreach ( $decoded['prefixes'] as $entry ) {
						if ( ! empty( $entry['ipv4Prefix'] ) ) {
							$ranges[] = (string) $entry['ipv4Prefix'];
						}
						if ( ! empty( $entry['ipv6Prefix'] ) ) {
							$ranges[] = (string) $entry['ipv6Prefix'];
						}
					}
				}
			} elseif ( 'text' === $cfg['format'] ) {
				foreach ( explode( "\n", $body ) as $line ) {
					$line = trim( $line );
					if ( '' !== $line ) {
						$ranges[] = $line;
					}
				}
			}
			if ( ! empty( $ranges ) ) {
				$new_sources[ $key ] = $ranges;
			} elseif ( isset( $prev[ $key ] ) ) {
				$new_sources[ $key ] = $prev[ $key ];
			}
		}

		// Agréger par groupe logique pour simplifier la vérification.
		$merged = array(
			'google'      => array(),
			'openai'      => array(),
			'perplexity'  => array(),
			'cloudflare'  => array(),
		);
		foreach ( array( 'google_common', 'google_special', 'google_triggered', 'google_triggered2' ) as $k ) {
			if ( ! empty( $new_sources[ $k ] ) ) {
				$merged['google'] = array_merge( $merged['google'], $new_sources[ $k ] );
			}
		}
		foreach ( array( 'openai_gptbot', 'openai_searchbot', 'openai_chatgpt' ) as $k ) {
			if ( ! empty( $new_sources[ $k ] ) ) {
				$merged['openai'] = array_merge( $merged['openai'], $new_sources[ $k ] );
			}
		}
		foreach ( array( 'perplexity_bot', 'perplexity_user' ) as $k ) {
			if ( ! empty( $new_sources[ $k ] ) ) {
				$merged['perplexity'] = array_merge( $merged['perplexity'], $new_sources[ $k ] );
			}
		}
		foreach ( array( 'cloudflare_v4', 'cloudflare_v6' ) as $k ) {
			if ( ! empty( $new_sources[ $k ] ) ) {
				$merged['cloudflare'] = array_merge( $merged['cloudflare'], $new_sources[ $k ] );
			}
		}
		// Deduplication.
		foreach ( $merged as $key => $list ) {
			$merged[ $key ] = array_values( array_unique( $list ) );
		}

		// Filet de securite : ne jamais ecraser un groupe existant par du vide
		// (ex : tous les endpoints d'un groupe en echec lors de ce refresh).
		foreach ( $merged as $key => $list ) {
			if ( empty( $list ) && ! empty( $prev_merged[ $key ] ) ) {
				$merged[ $key ] = $prev_merged[ $key ];
			}
		}

		update_option( 'aivt_ip_ranges', array(
			'fetched_at' => time(),
			'sources'    => $merged,
			'endpoints'  => $new_sources,
		), false );

		// Re-planifier le cron si absent (auto-reparation).
		if ( ! wp_next_scheduled( 'aivt_refresh_ip_ranges' ) ) {
			wp_schedule_event( time() + WEEK_IN_SECONDS, 'weekly', 'aivt_refresh_ip_ranges' );
		}
	}

	/**
	 * Retourne les plages IP pour une source canonique (ou un groupe logique).
	 *
	 * Les editeurs sans plages publiees (anthropic, meta, apple...) retournent
	 * un tableau vide -> verified restera NULL a la capture.
	 *
	 * @param string $source Source canonique (ex : 'google', 'openai').
	 * @return array<int,string> Liste de CIDR.
	 */
	private function get_ip_ranges_for_source( $source ) {
		$data = get_option( 'aivt_ip_ranges', array() );
		if ( empty( $data['sources'] ) ) {
			return array();
		}
		$sources = (array) $data['sources'];
		if ( isset( $sources[ $source ] ) && is_array( $sources[ $source ] ) ) {
			return $sources[ $source ];
		}
		return array();
	}

	/**
	 * Vérifie si une adresse IP appartient à l'un des CIDR de la liste.
	 *
	 * Supporte IPv4 et IPv6. Un CIDR sans notation /n est traité comme une IP exacte.
	 *
	 * @param string        $ip    Adresse IP à vérifier.
	 * @param array<string> $cidrs Liste de CIDR.
	 * @return bool
	 */
	private function ip_in_any_cidr( $ip, $cidrs ) {
		if ( '' === $ip || empty( $cidrs ) ) {
			return false;
		}
		$ip_bin = @inet_pton( $ip );
		if ( false === $ip_bin ) {
			return false;
		}
		$ip_len = strlen( $ip_bin );
		foreach ( $cidrs as $cidr ) {
			if ( strpos( $cidr, '/' ) !== false ) {
				list( $base, $bits ) = explode( '/', $cidr, 2 );
				$bits = (int) $bits;
			} else {
				$base = $cidr;
				$bits = -1;
			}
			$base_bin = @inet_pton( $base );
			if ( false === $base_bin ) {
				continue;
			}
			$base_len = strlen( $base_bin );
			// Ignorer si protocoles differents (IPv4 vs IPv6).
			if ( $ip_len !== $base_len ) {
				continue;
			}
			if ( $bits < 0 ) {
				// IP exacte.
				if ( $ip_bin === $base_bin ) {
					return true;
				}
				continue;
			}
			// Comparaison par masque de bits.
			$full_bytes = (int) floor( $bits / 8 );
			$rem_bits   = $bits % 8;
			if ( $full_bytes > 0 && substr( $ip_bin, 0, $full_bytes ) !== substr( $base_bin, 0, $full_bytes ) ) {
				continue;
			}
			if ( $rem_bits > 0 ) {
				$mask = 0xFF & ( 0xFF << ( 8 - $rem_bits ) );
				if ( ( ord( $ip_bin[ $full_bytes ] ) & $mask ) !== ( ord( $base_bin[ $full_bytes ] ) & $mask ) ) {
					continue;
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * Détermine si une URL pointe vers un fichier technique (asset) plutôt
	 * que vers du contenu, d'après l'extension de son chemin.
	 *
	 * @param string $url URL ou URI (querystring tolérée).
	 * @return int 1 si asset, 0 sinon.
	 */
	private function is_asset_url( $url ) {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		if ( '' === $path ) {
			$path = (string) $url;
		}
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		return ( '' !== $ext && in_array( $ext, self::ASSET_EXTENSIONS, true ) ) ? 1 : 0;
	}

	/**
	 * Enregistre la page d'admin (entree de niveau 1 dans le menu WordPress).
	 *
	 * @return void
	 */
	public function register_admin_page() {
		// Icone : SVG du path 'cpu' encode en base64, couleur standard #a7aaad.
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#a7aaad" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
			. '<rect x="5" y="5" width="14" height="14" rx="3"/>'
			. '<rect x="9" y="9" width="6" height="6" rx="1"/>'
			. '<path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>'
			. '</svg>';
		$icon = 'data:image/svg+xml;base64,' . base64_encode( $svg );
		add_menu_page(
			__( 'Visibilite IA', 'ai-visit-tracker' ),
			__( 'Visibilite IA', 'ai-visit-tracker' ),
			'manage_options',
			self::ADMIN_SLUG,
			array( $this, 'render_admin_page' ),
			$icon
		);
	}

	/**
	 * Handler de purge (admin-post.php POST).
	 *
	 * @return void
	 */
	public function handle_purge() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'ai-visit-tracker' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'aivt_purge' );

		$target = isset( $_POST['target'] ) ? sanitize_text_field( wp_unslash( $_POST['target'] ) ) : '';
		$result = 'invalid';

		global $wpdb;
		$table = $this->get_table_name();

		if ( 'all' === $target ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$wpdb->query( "DELETE FROM {$table}" );
			$result = 'all';
		} elseif ( 'url' === $target ) {
			$url_hash = isset( $_POST['url_hash'] ) ? sanitize_key( wp_unslash( $_POST['url_hash'] ) ) : '';
			if ( preg_match( '/^[a-f0-9]{40}$/', $url_hash ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->delete( $table, array( 'url_hash' => $url_hash ), array( '%s' ) );
				$result = 'url';
			}
		}

		$redirect = add_query_arg(
			array(
				'page'   => self::ADMIN_SLUG,
				'purged' => $result,
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Handler de l'export CSV du top URLs avec les filtres courants.
	 *
	 * Colonnes : url ; visites ; derniere_visite.
	 * LIMIT 10 000 lignes maximum.
	 *
	 * @return void
	 */
	public function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Acces refuse.', 'ai-visit-tracker' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'aivt_export' );

		// Recuperer les filtres transmis en POST.
		$period      = isset( $_POST['period'] ) ? sanitize_key( wp_unslash( $_POST['period'] ) ) : 'all';
		$show_assets = isset( $_POST['show_assets'] ) && '1' === $_POST['show_assets'];
		$source      = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : '';
		if ( ! isset( self::SOURCE_LABELS[ $source ] ) ) {
			$source = '';
		}
		$purpose = isset( $_POST['purpose'] ) ? sanitize_key( wp_unslash( $_POST['purpose'] ) ) : '';
		if ( ! isset( self::PURPOSE_LABELS[ $purpose ] ) ) {
			$purpose = '';
		}

		global $wpdb;
		$table = $this->get_table_name();

		// Construire le WHERE.
		$filters    = $this->build_filters_where( $source, $purpose, $show_assets );
		$conditions = $filters['conditions'];
		$params     = $filters['params'];

		if ( 'all' !== $period && is_numeric( $period ) && (int) $period > 0 ) {
			$conditions[] = 'visit_at >= %s';
			$params[]     = $this->period_start( (int) $period );
		}

		$where_sql = $conditions ? 'WHERE ' . implode( ' AND ', $conditions ) : '';

		$query_params = array_merge( $params, array( 10000 ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT url, COUNT(*) AS visits, MAX(visit_at) AS last_seen
			 FROM {$table} {$where_sql}
			 GROUP BY url_hash, url
			 ORDER BY visits DESC, last_seen DESC
			 LIMIT %d",
			$query_params
		), ARRAY_A );

		$filename = 'ai-visit-tracker-' . wp_date( 'Ymd' ) . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$out = fopen( 'php://output', 'w' );
		// BOM UTF-8 pour Excel.
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'url', 'visites', 'derniere_visite' ), ';' );

		foreach ( (array) $rows as $r ) {
			fputcsv( $out, array( $r['url'], $r['visits'], $r['last_seen'] ), ';' );
		}
		fclose( $out );
		exit;
	}

	/**
	 * Dispatcher de la page d'admin (vue liste / detail URL / detail source).
	 *
	 * @return void
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'ai-visit-tracker' ) );
		}

		// Auto-réparation : si les plages IP sont absentes ou vieilles de plus de 8 jours,
		// rafraichir immédiatement en contexte admin (acceptable) et re-planifier le cron.
		$ip_data = get_option( 'aivt_ip_ranges', array() );
		$stale   = empty( $ip_data ) || empty( $ip_data['fetched_at'] ) ||
					( time() - (int) $ip_data['fetched_at'] ) > 8 * DAY_IN_SECONDS;
		if ( $stale ) {
			$this->refresh_ip_ranges();
		}
		if ( ! wp_next_scheduled( 'aivt_refresh_ip_ranges' ) ) {
			wp_schedule_event( time() + WEEK_IN_SECONDS, 'weekly', 'aivt_refresh_ip_ranges' );
		}

		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'list';

		if ( 'detail_url' === $view ) {
			$this->render_url_detail();
			return;
		}
		if ( 'detail_source' === $view ) {
			$this->render_source_detail();
			return;
		}
		if ( 'detail_content' === $view ) {
			$this->render_content_detail();
			return;
		}
		if ( 'detail_purpose' === $view ) {
			$this->render_purpose_detail();
			return;
		}
		$this->render_list_view();
	}

	/**
	 * Vue principale : tableau de bord global.
	 *
	 * @return void
	 */
	private function render_list_view() {
		// Période : 1 / 7 / 30 / 90 / 365 jours, ou 'all' (tout l'historique).
		$allowed_periods = array( '1', '7', '30', '90', '365', 'all' );
		$period          = isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : '30';
		if ( ! in_array( $period, $allowed_periods, true ) ) {
			$period = '30';
		}
		$is_all = ( 'all' === $period );
		$source  = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
		$purpose = isset( $_GET['purpose'] ) ? sanitize_key( wp_unslash( $_GET['purpose'] ) ) : '';
		$paged   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		// Bascule : inclure les fichiers techniques (assets) dans les statistiques.
		$show_assets = isset( $_GET['show_assets'] ) && '1' === $_GET['show_assets'];

		if ( '' !== $source && ! isset( self::SOURCE_LABELS[ $source ] ) ) {
			$source = '';
		}
		if ( '' !== $purpose && ! isset( self::PURPOSE_LABELS[ $purpose ] ) ) {
			$purpose = '';
		}

		// En mode « Tout », les agrégats couvrent tout l'historique ; l'histogramme
		// est borné à 365 barres pour rester lisible.
		$span       = $this->get_data_span_days();
		$query_days = $is_all ? ( $span + 1 ) : (int) $period;
		$hist_days  = $is_all ? max( 1, min( $span + 1, 365 ) ) : (int) $period;

		// Source et finalité fonctionnent en « faceting » : chaque filtre découpe
		// tout le tableau de bord, sauf son propre panneau de répartition.
		$stats         = $this->get_global_stats( $show_assets, $source, $purpose );
		$by_source     = $this->get_source_breakdown( $query_days, $show_assets, $purpose, $source );
		$by_purpose    = $this->get_purpose_breakdown( $query_days, $show_assets, $source, $purpose );
		$top_urls      = $this->get_top_urls_paged( $query_days, $paged, 50, $source, $show_assets, $purpose );
		$by_content    = $this->get_content_visibility( $query_days, $source, $purpose );
		$asset_summary = $this->get_asset_summary( $query_days, $source, $purpose );
		$histogram     = $this->get_histogram( $hist_days, $show_assets, $source, $purpose );

		$max_hist = 1;
		foreach ( $histogram as $h ) {
			if ( $h['total'] > $max_hist ) {
				$max_hist = $h['total'];
			}
		}
		$max_source = 1;
		$sum_source = 0;
		foreach ( $by_source as $s ) {
			$sum_source += $s['total'];
			if ( $s['total'] > $max_source ) {
				$max_source = $s['total'];
			}
		}
		$max_purpose = 1;
		$sum_purpose = 0;
		foreach ( $by_purpose as $p ) {
			$sum_purpose += $p['total'];
			if ( $p['total'] > $max_purpose ) {
				$max_purpose = $p['total'];
			}
		}
		$max_content = 1;
		foreach ( $by_content as $c ) {
			if ( $c['visits'] > $max_content ) {
				$max_content = $c['visits'];
			}
		}

		// Arguments de base préservés par le sélecteur de période.
		$base_args = array( 'page' => self::ADMIN_SLUG );
		if ( '' !== $source ) {
			$base_args['source'] = $source;
		}
		if ( '' !== $purpose ) {
			$base_args['purpose'] = $purpose;
		}
		if ( $show_assets ) {
			$base_args['show_assets'] = '1';
		}

		// Base pour la bascule technique (préserve période + source + finalité).
		$toggle_base = array( 'page' => self::ADMIN_SLUG, 'period' => $period );
		if ( '' !== $source ) {
			$toggle_base['source'] = $source;
		}
		if ( '' !== $purpose ) {
			$toggle_base['purpose'] = $purpose;
		}
		$url_content    = add_query_arg( $toggle_base, admin_url( 'admin.php' ) );
		$url_all        = add_query_arg( array_merge( $toggle_base, array( 'show_assets' => '1' ) ), admin_url( 'admin.php' ) );
		$active_sources = $this->get_active_sources( $source );

		// Arguments de contexte transportes vers les vues detail (period, show_assets,
		// et le filtre de l'AUTRE dimension active).
		$ctx_source  = array( 'period' => $period );
		if ( $show_assets ) {
			$ctx_source['show_assets'] = '1';
		}
		if ( '' !== $purpose ) {
			$ctx_source['purpose'] = $purpose;
		}
		$ctx_purpose = array( 'period' => $period );
		if ( $show_assets ) {
			$ctx_purpose['show_assets'] = '1';
		}
		if ( '' !== $source ) {
			$ctx_purpose['source'] = $source;
		}
		$ctx_content = array( 'period' => $period );
		if ( $show_assets ) {
			$ctx_content['show_assets'] = '1';
		}
		if ( '' !== $source ) {
			$ctx_content['source'] = $source;
		}
		if ( '' !== $purpose ) {
			$ctx_content['purpose'] = $purpose;
		}
		?>
		<div class="wrap aivt-app">
			<?php $this->render_purge_notice(); ?>

			<header class="aivt-topbar">
				<div class="aivt-brand">
					<span class="aivt-brand-badge"><?php $this->icon( 'cpu' ); ?></span>
					<div>
						<h1 class="aivt-title"><?php esc_html_e( 'Visibilité IA', 'ai-visit-tracker' ); ?></h1>
						<p class="aivt-subtitle"><?php esc_html_e( 'Quelles plateformes explorent votre site, pourquoi et quels contenus.', 'ai-visit-tracker' ); ?></p>
					</div>
				</div>

				<div class="aivt-toolbar">
					<nav class="aivt-seg" aria-label="<?php esc_attr_e( 'Période analysée', 'ai-visit-tracker' ); ?>">
						<?php
						$periods = array(
							'1'   => __( '24 h', 'ai-visit-tracker' ),
							'7'   => __( '7 j', 'ai-visit-tracker' ),
							'30'  => __( '30 j', 'ai-visit-tracker' ),
							'90'  => __( '90 j', 'ai-visit-tracker' ),
							'365' => __( '1 an', 'ai-visit-tracker' ),
							'all' => __( 'Tout', 'ai-visit-tracker' ),
						);
						foreach ( $periods as $pkey => $label ) :
							$purl = add_query_arg( array_merge( $base_args, array( 'period' => $pkey ) ), admin_url( 'admin.php' ) );
							$on   = ( $period === (string) $pkey );
							?>
							<a class="aivt-seg-item<?php echo $on ? ' is-active' : ''; ?>" href="<?php echo esc_url( $purl ); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
						<?php endforeach; ?>
					</nav>

					<nav class="aivt-seg" aria-label="<?php esc_attr_e( 'Inclure les fichiers techniques (CSS, JS, images…)', 'ai-visit-tracker' ); ?>">
						<a class="aivt-seg-item<?php echo $show_assets ? '' : ' is-active'; ?>" href="<?php echo esc_url( $url_content ); ?>"<?php echo $show_assets ? '' : ' aria-current="page"'; ?>><?php esc_html_e( 'Contenu', 'ai-visit-tracker' ); ?></a>
						<a class="aivt-seg-item<?php echo $show_assets ? ' is-active' : ''; ?>" href="<?php echo esc_url( $url_all ); ?>"<?php echo $show_assets ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'Tout', 'ai-visit-tracker' ); ?></a>
					</nav>

					<form method="get" class="aivt-source-filter">
						<input type="hidden" name="page" value="<?php echo esc_attr( self::ADMIN_SLUG ); ?>">
						<input type="hidden" name="period" value="<?php echo esc_attr( $period ); ?>">
						<?php if ( $show_assets ) : ?>
							<input type="hidden" name="show_assets" value="1">
						<?php endif; ?>
						<span class="aivt-select-wrap">
							<?php $this->icon( 'filter' ); ?>
							<select name="source" onchange="this.form.submit()" aria-label="<?php esc_attr_e( 'Filtrer par source', 'ai-visit-tracker' ); ?>">
								<option value=""><?php esc_html_e( 'Toutes les sources', 'ai-visit-tracker' ); ?></option>
								<?php foreach ( $active_sources as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $source, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</span>
						<span class="aivt-select-wrap">
							<?php $this->icon( 'target' ); ?>
							<select name="purpose" onchange="this.form.submit()" aria-label="<?php esc_attr_e( 'Filtrer par finalité', 'ai-visit-tracker' ); ?>">
								<option value=""><?php esc_html_e( 'Toutes les finalités', 'ai-visit-tracker' ); ?></option>
								<?php foreach ( self::PURPOSE_LABELS as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $purpose, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</span>
					</form>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( 'aivt_export' ); ?>
						<input type="hidden" name="action" value="aivt_export">
						<input type="hidden" name="period" value="<?php echo esc_attr( $period ); ?>">
						<input type="hidden" name="show_assets" value="<?php echo $show_assets ? '1' : '0'; ?>">
						<input type="hidden" name="source" value="<?php echo esc_attr( $source ); ?>">
						<input type="hidden" name="purpose" value="<?php echo esc_attr( $purpose ); ?>">
						<button type="submit" class="aivt-btn aivt-btn-ghost"><?php $this->icon( 'download' ); ?><span><?php esc_html_e( 'Exporter', 'ai-visit-tracker' ); ?></span></button>
					</form>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="aivt-purge-all"
						onsubmit="return confirm('<?php echo esc_js( __( 'Confirmer la suppression de TOUTES les visites IA ? Cette action est irreversible.', 'ai-visit-tracker' ) ); ?>');">
						<?php wp_nonce_field( 'aivt_purge' ); ?>
						<input type="hidden" name="action" value="aivt_purge">
						<input type="hidden" name="target" value="all">
						<button type="submit" class="aivt-btn aivt-btn-danger"><?php $this->icon( 'trash' ); ?><span><?php esc_html_e( 'Tout purger', 'ai-visit-tracker' ); ?></span></button>
					</form>
				</div>
			</header>

			<section class="aivt-kpis">
				<?php
				$card_specs = array(
					array( 'label' => __( 'Aujourd\'hui', 'ai-visit-tracker' ),       'value' => $stats['bot_24h'],   'icon' => 'pulse',    'tone' => 'indigo' ),
					array( 'label' => __( '7 derniers jours', 'ai-visit-tracker' ),  'value' => $stats['bot_7d'],    'icon' => 'calendar', 'tone' => 'violet' ),
					array( 'label' => __( '30 derniers jours', 'ai-visit-tracker' ), 'value' => $stats['bot_30d'],   'icon' => 'chart',    'tone' => 'blue' ),
					array( 'label' => __( 'Total cumulé', 'ai-visit-tracker' ),      'value' => $stats['bot_total'], 'icon' => 'sigma',    'tone' => 'emerald' ),
				);
				foreach ( $card_specs as $card ) :
					?>
					<article class="aivt-kpi aivt-tone-<?php echo esc_attr( $card['tone'] ); ?>">
						<span class="aivt-kpi-icon"><?php $this->icon( $card['icon'] ); ?></span>
						<span class="aivt-kpi-label"><?php echo esc_html( $card['label'] ); ?></span>
						<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $card['value'] ); ?>"><?php echo esc_html( number_format_i18n( $card['value'] ) ); ?></span>
					</article>
				<?php endforeach; ?>
			</section>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'chart' ); ?> <?php esc_html_e( 'Activité des crawlers', 'ai-visit-tracker' ); ?></h2>
					<span class="aivt-panel-meta">
						<?php
						if ( $is_all ) {
							esc_html_e( 'tout l\'historique', 'ai-visit-tracker' );
						} else {
							/* translators: %d: number of days */
							printf( esc_html( _n( 'sur %d jour', 'sur %d jours', $hist_days, 'ai-visit-tracker' ) ), (int) $hist_days );
						}
						?>
					</span>
				</div>
				<?php $this->render_chart( $histogram, $max_hist ); ?>
			</section>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'target' ); ?> <?php esc_html_e( 'Finalités des visites', 'ai-visit-tracker' ); ?></h2>
					<span class="aivt-panel-meta"><?php esc_html_e( 'pourquoi les IA explorent', 'ai-visit-tracker' ); ?></span>
				</div>
				<?php if ( empty( $by_purpose ) ) : ?>
					<?php $this->render_empty( __( 'Aucune visite IA sur la période.', 'ai-visit-tracker' ) ); ?>
				<?php else : ?>
					<ul class="aivt-rank">
						<?php foreach ( $by_purpose as $row ) :
							$purpose_url = add_query_arg(
								array_merge(
									array(
										'page'    => self::ADMIN_SLUG,
										'view'    => 'detail_purpose',
										'purpose' => $row['ai_purpose'],
									),
									$ctx_purpose
								),
								admin_url( 'admin.php' )
							);
							$color = $this->purpose_color( $row['ai_purpose'] );
							$pct   = ( $row['total'] / $max_purpose ) * 100;
							$share = $sum_purpose > 0 ? round( ( $row['total'] / $sum_purpose ) * 100 ) : 0;
							?>
							<li class="aivt-rank-item">
								<a class="aivt-rank-link" href="<?php echo esc_url( $purpose_url ); ?>">
									<span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span>
									<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::PURPOSE_LABELS, $row['ai_purpose'] ) ); ?></span>
									<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
								</a>
								<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $color ); ?>"></span></span>
								<span class="aivt-rank-foot">
									<span class="aivt-muted"><?php echo esc_html( $share ); ?>%</span>
									<span class="aivt-muted"><?php echo esc_html( $this->format_date( $row['last_seen'] ) ); ?></span>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</section>

			<div class="aivt-grid">
				<section class="aivt-panel">
					<div class="aivt-panel-head">
						<h2><?php $this->icon( 'cpu' ); ?> <?php esc_html_e( 'Plateformes', 'ai-visit-tracker' ); ?></h2>
					</div>
					<?php if ( empty( $by_source ) ) : ?>
						<?php $this->render_empty( __( 'Aucune visite IA sur la période.', 'ai-visit-tracker' ) ); ?>
					<?php else : ?>
						<ul class="aivt-rank">
							<?php foreach ( $by_source as $row ) :
								$detail_url = add_query_arg(
									array_merge(
										array(
											'page'   => self::ADMIN_SLUG,
											'view'   => 'detail_source',
											'source' => $row['ai_source'],
										),
										$ctx_source
									),
									admin_url( 'admin.php' )
								);
								$color = $this->source_color( $row['ai_source'] );
								$pct   = ( $row['total'] / $max_source ) * 100;
								$share = $sum_source > 0 ? round( ( $row['total'] / $sum_source ) * 100 ) : 0;
								?>
								<li class="aivt-rank-item">
									<a class="aivt-rank-link" href="<?php echo esc_url( $detail_url ); ?>">
										<span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span>
										<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $row['ai_source'] ) ); ?></span>
										<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
									</a>
									<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $color ); ?>"></span></span>
									<span class="aivt-rank-foot">
										<span class="aivt-muted"><?php echo esc_html( $share ); ?>%</span>
										<span class="aivt-muted"><?php echo esc_html( $this->format_date( $row['last_seen'] ) ); ?></span>
									</span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</section>

				<section class="aivt-panel">
					<div class="aivt-panel-head">
						<h2><?php $this->icon( 'layers' ); ?> <?php esc_html_e( 'Visibilité par contenu', 'ai-visit-tracker' ); ?></h2>
					</div>
					<?php if ( empty( $by_content ) && $asset_summary['visits'] < 1 ) : ?>
						<?php $this->render_empty( __( 'Aucune donnée sur la période.', 'ai-visit-tracker' ) ); ?>
					<?php else : ?>
						<ul class="aivt-bars">
							<?php foreach ( $by_content as $row ) :
								$ct_url = add_query_arg(
									array_merge(
										array(
											'page'         => self::ADMIN_SLUG,
											'view'         => 'detail_content',
											'content_type' => $row['content_type'],
										),
										$ctx_content
									),
									admin_url( 'admin.php' )
								);
								$pct = ( $row['visits'] / $max_content ) * 100;
								?>
								<li class="aivt-bars-item">
									<a class="aivt-bars-link" href="<?php echo esc_url( $ct_url ); ?>">
										<span class="aivt-bars-ico"><?php $this->icon( $this->content_icon( $row['content_type'] ) ); ?></span>
										<span class="aivt-bars-name"><?php echo esc_html( $this->get_label( self::CONTENT_TYPE_LABELS, $row['content_type'] ) ); ?></span>
										<span class="aivt-bars-val"><?php echo esc_html( number_format_i18n( $row['visits'] ) ); ?></span>
									</a>
									<span class="aivt-bars-track"><span class="aivt-bars-fill" style="--w: <?php echo esc_attr( $pct ); ?>%"></span></span>
									<span class="aivt-bars-foot">
										<?php
										printf(
											/* translators: %s: number of distinct URLs */
											esc_html( _n( '%s URL distincte', '%s URLs distinctes', $row['urls'], 'ai-visit-tracker' ) ),
											esc_html( number_format_i18n( $row['urls'] ) )
										);
										?>
									</span>
								</li>
							<?php endforeach; ?>

							<?php if ( $asset_summary['visits'] > 0 ) :
								$asset_url = add_query_arg(
									array(
										'page'         => self::ADMIN_SLUG,
										'view'         => 'detail_content',
										'content_type' => 'asset',
									),
									admin_url( 'admin.php' )
								);
								?>
								<li class="aivt-bars-item">
									<a class="aivt-bars-link" href="<?php echo esc_url( $asset_url ); ?>">
										<span class="aivt-bars-ico"><?php $this->icon( 'code' ); ?></span>
										<span class="aivt-bars-name"><?php esc_html_e( 'Fichiers techniques', 'ai-visit-tracker' ); ?></span>
										<span class="aivt-bars-val"><?php echo esc_html( number_format_i18n( $asset_summary['visits'] ) ); ?></span>
									</a>
									<span class="aivt-bars-foot">
										<?php
										printf(
											/* translators: %s: number of distinct URLs */
											esc_html( _n( '%s URL distincte', '%s URLs distinctes', $asset_summary['urls'], 'ai-visit-tracker' ) ),
											esc_html( number_format_i18n( $asset_summary['urls'] ) )
										);
										echo ' · ';
										echo $show_assets
											? esc_html__( 'incluses dans les stats', 'ai-visit-tracker' )
											: esc_html__( 'exclues par défaut', 'ai-visit-tracker' );
										?>
									</span>
								</li>
							<?php endif; ?>
						</ul>
					<?php endif; ?>
				</section>
			</div>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'link' ); ?> <?php esc_html_e( 'Top URLs explorees', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_top_urls_table( $top_urls, $paged ); ?>
			</section>

			<?php
			$footprint = $this->get_storage_footprint();
			if ( $footprint['rows'] > 0 ) :
				?>
			<p class="aivt-storage">
				<?php
				printf(
					/* translators: 1: taille formatee, 2: nombre de visites */
					esc_html__( 'Stockage du plugin : %1$s &middot; %2$s visites enregistrees', 'ai-visit-tracker' ),
					esc_html( size_format( $footprint['bytes'] ) ),
					esc_html( number_format_i18n( $footprint['rows'] ) )
				);
				?>
			</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Rend une table de top URLs avec pagination.
	 *
	 * @param array{rows:array,total:int,total_pages:int} $result
	 * @param int                                          $paged Numéro de page courant.
	 * @return void
	 */
	private function render_top_urls_table( $result, $paged ) {
		$rows = isset( $result['rows'] ) ? (array) $result['rows'] : array();

		if ( empty( $rows ) ) {
			$this->render_empty( __( 'Aucune URL explorée sur la période.', 'ai-visit-tracker' ) );
			return;
		}

		$max = 1;
		foreach ( $rows as $r ) {
			if ( $r['visits'] > $max ) {
				$max = $r['visits'];
			}
		}
		?>
		<div class="aivt-table-wrap">
			<table class="aivt-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'URL', 'ai-visit-tracker' ); ?></th>
						<th class="aivt-num"><?php esc_html_e( 'Visites', 'ai-visit-tracker' ); ?></th>
						<th class="aivt-right"><?php esc_html_e( 'Dernière', 'ai-visit-tracker' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $row ) :
						$detail_url = add_query_arg(
							array(
								'page'     => self::ADMIN_SLUG,
								'view'     => 'detail_url',
								'url_hash' => $row['url_hash'],
							),
							admin_url( 'admin.php' )
						);
						$pct = ( $row['visits'] / $max ) * 100;
						?>
						<tr data-href="<?php echo esc_url( $detail_url ); ?>">
							<td class="aivt-url-cell">
								<a href="<?php echo esc_url( $detail_url ); ?>" title="<?php echo esc_attr( $row['url'] ); ?>"><span class="aivt-url"><?php echo esc_html( $row['url'] ); ?></span></a>
								<span class="aivt-rowbar"><span style="--w: <?php echo esc_attr( $pct ); ?>%"></span></span>
							</td>
							<td class="aivt-num"><span class="aivt-count"><?php echo esc_html( number_format_i18n( $row['visits'] ) ); ?></span></td>
							<td class="aivt-right aivt-muted"><?php echo esc_html( $this->format_date( $row['last_seen'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		$this->render_pagination(
			isset( $result['total'] ) ? (int) $result['total'] : 0,
			isset( $result['total_pages'] ) ? (int) $result['total_pages'] : 0,
			$paged
		);
	}

	/**
	 * Vue détail d'une URL : timeline des visites IA sur cette URL.
	 *
	 * @return void
	 */
	private function render_url_detail() {
		$url_hash = isset( $_GET['url_hash'] ) ? sanitize_key( wp_unslash( $_GET['url_hash'] ) ) : '';
		$list_url = add_query_arg( array( 'page' => self::ADMIN_SLUG ), admin_url( 'admin.php' ) );

		if ( ! preg_match( '/^[a-f0-9]{40}$/', $url_hash ) ) {
			$this->render_state( __( 'Identifiant invalide', 'ai-visit-tracker' ), __( 'L\'URL demandée est introuvable.', 'ai-visit-tracker' ), $list_url, 'alert' );
			return;
		}

		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$detail = $this->get_url_detail_data( $url_hash, $paged );
		// Récupérer la page effective (capped par get_url_detail_data)
		$paged = isset( $detail['paged'] ) ? (int) $detail['paged'] : $paged;

		if ( '' === $detail['url'] ) {
			$this->render_state( __( 'Aucune visite', 'ai-visit-tracker' ), __( 'Aucune visite IA n\'a été enregistrée pour cette URL.', 'ai-visit-tracker' ), $list_url, 'ghost' );
			return;
		}
		?>
		<div class="wrap aivt-app aivt-detailview">
			<?php $this->render_purge_notice(); ?>

			<a class="aivt-back" href="<?php echo esc_url( $list_url ); ?>"><?php $this->icon( 'back' ); ?> <?php esc_html_e( 'Retour au tableau de bord', 'ai-visit-tracker' ); ?></a>

			<header class="aivt-dethead">
				<div class="aivt-dethead-main">
					<span class="aivt-dethead-kicker"><?php $this->icon( 'link' ); ?> <?php esc_html_e( 'URL explorée', 'ai-visit-tracker' ); ?></span>
					<h1 class="aivt-dethead-url is-mono"><?php echo esc_html( $detail['url'] ); ?></h1>
				</div>
				<div class="aivt-dethead-actions">
					<a class="aivt-btn aivt-btn-ghost" href="<?php echo esc_url( home_url( $detail['url'] ) ); ?>" target="_blank" rel="noopener"><?php $this->icon( 'external' ); ?><span><?php esc_html_e( 'Voir la page', 'ai-visit-tracker' ); ?></span></a>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
						onsubmit="return confirm('<?php echo esc_js( __( 'Supprimer toutes les visites IA enregistrées pour cette URL ?', 'ai-visit-tracker' ) ); ?>');">
						<?php wp_nonce_field( 'aivt_purge' ); ?>
						<input type="hidden" name="action" value="aivt_purge">
						<input type="hidden" name="target" value="url">
						<input type="hidden" name="url_hash" value="<?php echo esc_attr( $url_hash ); ?>">
						<button type="submit" class="aivt-btn aivt-btn-danger"><?php $this->icon( 'trash' ); ?><span><?php esc_html_e( 'Purger', 'ai-visit-tracker' ); ?></span></button>
					</form>
				</div>
			</header>

			<section class="aivt-kpis">
				<article class="aivt-kpi aivt-tone-indigo">
					<span class="aivt-kpi-icon"><?php $this->icon( 'pulse' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Total visites', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['total'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['total'] ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-violet">
					<span class="aivt-kpi-icon"><?php $this->icon( 'cpu' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Sources distinctes', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( count( $detail['by_source'] ) ); ?>"><?php echo esc_html( number_format_i18n( count( $detail['by_source'] ) ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-blue">
					<span class="aivt-kpi-icon"><?php $this->icon( 'calendar' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Premier hit', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-sub"><?php echo esc_html( $this->format_date( $detail['stats']['first_seen'] ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-emerald">
					<span class="aivt-kpi-icon"><?php $this->icon( 'pulse' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Dernier hit', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-sub"><?php echo esc_html( $this->format_date( $detail['stats']['last_seen'] ) ); ?></span>
				</article>
			</section>

			<div class="aivt-grid">
				<section class="aivt-panel">
					<div class="aivt-panel-head">
						<h2><?php $this->icon( 'cpu' ); ?> <?php esc_html_e( 'Répartition par source', 'ai-visit-tracker' ); ?></h2>
					</div>
					<?php if ( empty( $detail['by_source'] ) ) : ?>
						<?php $this->render_empty( __( 'Aucune source.', 'ai-visit-tracker' ) ); ?>
					<?php else :
						$max_src = 1;
						foreach ( $detail['by_source'] as $r ) {
							if ( $r['total'] > $max_src ) {
								$max_src = $r['total'];
							}
						}
						?>
						<ul class="aivt-rank">
							<?php foreach ( $detail['by_source'] as $row ) :
								$color = $this->source_color( $row['ai_source'] );
								$pct   = ( $row['total'] / $max_src ) * 100;
								?>
								<li class="aivt-rank-item">
									<span class="aivt-rank-link">
										<span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span>
										<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $row['ai_source'] ) ); ?></span>
										<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
									</span>
									<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $color ); ?>"></span></span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</section>

				<section class="aivt-panel">
					<div class="aivt-panel-head">
						<h2><?php $this->icon( 'target' ); ?> <?php esc_html_e( 'Finalités sur cette URL', 'ai-visit-tracker' ); ?></h2>
					</div>
					<?php $this->render_purpose_rank( isset( $detail['by_purpose'] ) ? $detail['by_purpose'] : array() ); ?>
				</section>
			</div>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'pulse' ); ?> <?php esc_html_e( 'Journal des visites', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php if ( empty( $detail['rows'] ) ) : ?>
					<?php $this->render_empty( __( 'Aucune visite.', 'ai-visit-tracker' ) ); ?>
				<?php else : ?>
					<div class="aivt-table-wrap">
						<table class="aivt-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Horodatage', 'ai-visit-tracker' ); ?></th>
									<th><?php esc_html_e( 'Source', 'ai-visit-tracker' ); ?></th>
									<th><?php esc_html_e( 'Finalité', 'ai-visit-tracker' ); ?></th>
									<th><?php esc_html_e( 'IP', 'ai-visit-tracker' ); ?></th>
									<th><?php esc_html_e( 'User-Agent', 'ai-visit-tracker' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $detail['rows'] as $hit ) : ?>
									<tr>
										<td class="aivt-muted" style="white-space:nowrap;"><?php echo esc_html( $this->format_date( $hit['visit_at'] ) ); ?></td>
										<td>
											<span class="aivt-srcchip">
												<span class="aivt-dot" style="--c: <?php echo esc_attr( $this->source_color( $hit['ai_source'] ) ); ?>"></span>
												<span>
													<?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $hit['ai_source'] ) ); ?>
													<span class="aivt-srcsub"><?php echo esc_html( $hit['ai_label'] ); ?></span>
												</span>
											</span>
										</td>
										<td><?php $this->render_purpose_badge( $hit['ai_purpose'] ); ?></td>
										<td>
											<span class="aivt-code"><?php echo esc_html( $hit['ip'] ?: '·' ); ?></span>
											<?php if ( 1 === $hit['verified'] ) : ?>
												<span class="aivt-verif-ok" title="<?php esc_attr_e( 'IP verifiee (plage officielle de l\'editeur)', 'ai-visit-tracker' ); ?>"><?php $this->icon( 'check' ); ?></span>
											<?php elseif ( 0 === $hit['verified'] ) : ?>
												<span class="aivt-verif-bad" title="<?php esc_attr_e( 'IP hors des plages officielles : usurpation probable', 'ai-visit-tracker' ); ?>"><?php $this->icon( 'alert' ); ?></span>
											<?php endif; ?>
										</td>
										<td>
											<?php if ( 'HEAD' === $hit['visit_type'] ) : ?>
												<span class="aivt-code">HEAD</span>
											<?php endif; ?>
											<span class="aivt-ua" title="<?php echo esc_attr( $hit['user_agent'] ); ?>"><?php echo esc_html( $hit['user_agent'] ?: '·' ); ?></span>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<?php $this->render_pagination( $detail['total'], $detail['total_pages'], $paged ); ?>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Vue détail d'une source IA : ce que cette IA a visité.
	 *
	 * @return void
	 */
	private function render_source_detail() {
		$source   = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';

		// Filtres contextuels (propagation depuis le tableau de bord).
		$period      = isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : 'all';
		if ( ! in_array( $period, array( '1', '7', '30', '90', '365', 'all' ), true ) ) {
			$period = 'all';
		}
		$show_assets = isset( $_GET['show_assets'] ) && '1' === $_GET['show_assets'];
		$ctx_purpose = isset( $_GET['purpose'] ) ? sanitize_key( wp_unslash( $_GET['purpose'] ) ) : '';
		if ( ! isset( self::PURPOSE_LABELS[ $ctx_purpose ] ) ) {
			$ctx_purpose = '';
		}

		$base_args = array( 'page' => self::ADMIN_SLUG );
		$back_args = array_merge( $base_args, array( 'period' => $period ) );
		if ( $show_assets ) {
			$back_args['show_assets'] = '1';
		}
		if ( '' !== $ctx_purpose ) {
			$back_args['purpose'] = $ctx_purpose;
		}
		$list_url = add_query_arg( $back_args, admin_url( 'admin.php' ) );

		if ( ! isset( self::SOURCE_LABELS[ $source ] ) ) {
			$this->render_state( __( 'Source inconnue', 'ai-visit-tracker' ), __( 'Cette plateforme n\'est pas reconnue.', 'ai-visit-tracker' ), $list_url, 'alert' );
			return;
		}

		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$detail = $this->get_source_detail_data( $source, $paged, $period, $show_assets, $ctx_purpose );
		// Recuperer la page effective (capped par get_source_detail_data)
		$paged = isset( $detail['paged'] ) ? (int) $detail['paged'] : $paged;
		$color = $this->source_color( $source );

		// Libelle de la periode active.
		$period_labels = array(
			'1'   => __( '24 h', 'ai-visit-tracker' ),
			'7'   => __( '7 jours', 'ai-visit-tracker' ),
			'30'  => __( '30 jours', 'ai-visit-tracker' ),
			'90'  => __( '90 jours', 'ai-visit-tracker' ),
			'365' => __( '365 jours', 'ai-visit-tracker' ),
			'all' => __( 'Tout', 'ai-visit-tracker' ),
		);
		$period_label = isset( $period_labels[ $period ] ) ? $period_labels[ $period ] : __( 'Tout', 'ai-visit-tracker' );
		?>
		<div class="wrap aivt-app aivt-detailview">
			<a class="aivt-back" href="<?php echo esc_url( $list_url ); ?>"><?php $this->icon( 'back' ); ?> <?php esc_html_e( 'Retour au tableau de bord', 'ai-visit-tracker' ); ?></a>

			<header class="aivt-dethead">
				<div class="aivt-dethead-main">
					<span class="aivt-dethead-kicker"><span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span> <?php esc_html_e( 'Plateforme', 'ai-visit-tracker' ); ?></span>
					<h1 class="aivt-dethead-url"><?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $source ) ); ?></h1>
					<?php if ( 'all' !== $period || $show_assets || '' !== $ctx_purpose ) : ?>
					<p class="aivt-dethead-ctx">
						<?php echo esc_html( $period_label ); ?>
						<?php if ( $show_assets ) : ?> &middot; <?php esc_html_e( 'Tout (assets inclus)', 'ai-visit-tracker' ); ?><?php endif; ?>
						<?php if ( '' !== $ctx_purpose ) : ?> &middot; <?php echo esc_html( $this->get_label( self::PURPOSE_LABELS, $ctx_purpose ) ); ?><?php endif; ?>
					</p>
					<?php endif; ?>
				</div>
			</header>

			<section class="aivt-kpis" style="grid-template-columns:repeat(2,1fr);">
				<article class="aivt-kpi aivt-tone-indigo">
					<span class="aivt-kpi-icon"><?php $this->icon( 'pulse' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Total visites', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['total'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['total'] ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-violet">
					<span class="aivt-kpi-icon"><?php $this->icon( 'link' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'URLs distinctes', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['urls'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['urls'] ) ); ?></span>
				</article>
			</section>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'target' ); ?> <?php esc_html_e( 'Finalites de cette plateforme', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_purpose_rank( isset( $detail['by_purpose'] ) ? $detail['by_purpose'] : array() ); ?>
			</section>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'link' ); ?> <?php esc_html_e( 'Top URLs explorees par cette source', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_top_urls_table( $detail, $paged ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Vue détail d'un type de contenu : ce que les IA explorent de ce type.
	 *
	 * @return void
	 */
	private function render_content_detail() {
		$content_type = isset( $_GET['content_type'] ) ? sanitize_key( wp_unslash( $_GET['content_type'] ) ) : '';

		// Filtres contextuels (propagation depuis le tableau de bord).
		$period      = isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : 'all';
		if ( ! in_array( $period, array( '1', '7', '30', '90', '365', 'all' ), true ) ) {
			$period = 'all';
		}
		$show_assets = isset( $_GET['show_assets'] ) && '1' === $_GET['show_assets'];
		$ctx_source  = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
		if ( ! isset( self::SOURCE_LABELS[ $ctx_source ] ) ) {
			$ctx_source = '';
		}
		$ctx_purpose = isset( $_GET['purpose'] ) ? sanitize_key( wp_unslash( $_GET['purpose'] ) ) : '';
		if ( ! isset( self::PURPOSE_LABELS[ $ctx_purpose ] ) ) {
			$ctx_purpose = '';
		}

		$base_args = array( 'page' => self::ADMIN_SLUG );
		$back_args = array_merge( $base_args, array( 'period' => $period ) );
		if ( $show_assets ) {
			$back_args['show_assets'] = '1';
		}
		if ( '' !== $ctx_source ) {
			$back_args['source'] = $ctx_source;
		}
		if ( '' !== $ctx_purpose ) {
			$back_args['purpose'] = $ctx_purpose;
		}
		$list_url = add_query_arg( $back_args, admin_url( 'admin.php' ) );

		if ( ! isset( self::CONTENT_TYPE_LABELS[ $content_type ] ) ) {
			$this->render_state( __( 'Type inconnu', 'ai-visit-tracker' ), __( 'Ce type de contenu n\'est pas reconnu.', 'ai-visit-tracker' ), $list_url, 'alert' );
			return;
		}

		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$detail = $this->get_content_detail_data( $content_type, $paged, $period, $ctx_source, $ctx_purpose );
		$paged  = isset( $detail['paged'] ) ? (int) $detail['paged'] : $paged;

		$period_labels = array(
			'1'   => __( '24 h', 'ai-visit-tracker' ),
			'7'   => __( '7 jours', 'ai-visit-tracker' ),
			'30'  => __( '30 jours', 'ai-visit-tracker' ),
			'90'  => __( '90 jours', 'ai-visit-tracker' ),
			'365' => __( '365 jours', 'ai-visit-tracker' ),
			'all' => __( 'Tout', 'ai-visit-tracker' ),
		);
		$period_label = isset( $period_labels[ $period ] ) ? $period_labels[ $period ] : __( 'Tout', 'ai-visit-tracker' );

		$max_src = 1;
		foreach ( $detail['by_source'] as $r ) {
			if ( $r['total'] > $max_src ) {
				$max_src = $r['total'];
			}
		}
		?>
		<div class="wrap aivt-app aivt-detailview">
			<a class="aivt-back" href="<?php echo esc_url( $list_url ); ?>"><?php $this->icon( 'back' ); ?> <?php esc_html_e( 'Retour au tableau de bord', 'ai-visit-tracker' ); ?></a>

			<header class="aivt-dethead">
				<div class="aivt-dethead-main">
					<span class="aivt-dethead-kicker"><?php $this->icon( $this->content_icon( $content_type ) ); ?> <?php esc_html_e( 'Type de contenu', 'ai-visit-tracker' ); ?></span>
					<h1 class="aivt-dethead-url"><?php echo esc_html( $this->get_label( self::CONTENT_TYPE_LABELS, $content_type ) ); ?></h1>
					<?php if ( 'all' !== $period || '' !== $ctx_source || '' !== $ctx_purpose ) : ?>
					<p class="aivt-dethead-ctx">
						<?php echo esc_html( $period_label ); ?>
						<?php if ( '' !== $ctx_source ) : ?> &middot; <?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $ctx_source ) ); ?><?php endif; ?>
						<?php if ( '' !== $ctx_purpose ) : ?> &middot; <?php echo esc_html( $this->get_label( self::PURPOSE_LABELS, $ctx_purpose ) ); ?><?php endif; ?>
					</p>
					<?php endif; ?>
				</div>
			</header>

			<section class="aivt-kpis" style="grid-template-columns:repeat(2,1fr);">
				<article class="aivt-kpi aivt-tone-indigo">
					<span class="aivt-kpi-icon"><?php $this->icon( 'pulse' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Total visites', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['total'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['total'] ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-violet">
					<span class="aivt-kpi-icon"><?php $this->icon( 'link' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'URLs distinctes', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['urls'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['urls'] ) ); ?></span>
				</article>
			</section>

			<?php if ( ! empty( $detail['by_source'] ) ) : ?>
			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'cpu' ); ?> <?php esc_html_e( 'Plateformes sur ce contenu', 'ai-visit-tracker' ); ?></h2>
				</div>
				<ul class="aivt-rank">
					<?php
					// Contexte propage vers le detail source (periode, assets, finalite).
					$src_ctx = array( 'period' => $period );
					if ( $show_assets ) {
						$src_ctx['show_assets'] = '1';
					}
					if ( '' !== $ctx_purpose ) {
						$src_ctx['purpose'] = $ctx_purpose;
					}
					foreach ( $detail['by_source'] as $row ) :
						$src_url = add_query_arg(
							array_merge(
								array(
									'page'   => self::ADMIN_SLUG,
									'view'   => 'detail_source',
									'source' => $row['ai_source'],
								),
								$src_ctx
							),
							admin_url( 'admin.php' )
						);
						$color = $this->source_color( $row['ai_source'] );
						$pct   = ( $row['total'] / $max_src ) * 100;
						?>
						<li class="aivt-rank-item">
							<a class="aivt-rank-link" href="<?php echo esc_url( $src_url ); ?>">
								<span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span>
								<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $row['ai_source'] ) ); ?></span>
								<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
							</a>
							<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $color ); ?>"></span></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
			<?php endif; ?>

			<?php if ( ! empty( $detail['by_purpose'] ) ) : ?>
			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'target' ); ?> <?php esc_html_e( 'Finalités sur ce contenu', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_purpose_rank( $detail['by_purpose'] ); ?>
			</section>
			<?php endif; ?>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'link' ); ?> <?php esc_html_e( 'Top URLs de ce type', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_top_urls_table( $detail, $paged ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Vue détail d'une finalité : top URLs et plateformes pour cette finalité.
	 *
	 * @return void
	 */
	private function render_purpose_detail() {
		$purpose = isset( $_GET['purpose'] ) ? sanitize_key( wp_unslash( $_GET['purpose'] ) ) : '';

		// Filtres contextuels (propagation depuis le tableau de bord).
		$period      = isset( $_GET['period'] ) ? sanitize_key( wp_unslash( $_GET['period'] ) ) : 'all';
		if ( ! in_array( $period, array( '1', '7', '30', '90', '365', 'all' ), true ) ) {
			$period = 'all';
		}
		$show_assets = isset( $_GET['show_assets'] ) && '1' === $_GET['show_assets'];
		$ctx_source  = isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '';
		if ( ! isset( self::SOURCE_LABELS[ $ctx_source ] ) ) {
			$ctx_source = '';
		}

		$base_args = array( 'page' => self::ADMIN_SLUG );
		$back_args = array_merge( $base_args, array( 'period' => $period ) );
		if ( $show_assets ) {
			$back_args['show_assets'] = '1';
		}
		if ( '' !== $ctx_source ) {
			$back_args['source'] = $ctx_source;
		}
		$list_url = add_query_arg( $back_args, admin_url( 'admin.php' ) );

		if ( ! isset( self::PURPOSE_LABELS[ $purpose ] ) ) {
			$this->render_state( __( 'Finalite inconnue', 'ai-visit-tracker' ), __( 'Cette finalite n\'est pas reconnue.', 'ai-visit-tracker' ), $list_url, 'alert' );
			return;
		}

		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$detail = $this->get_purpose_detail_data( $purpose, $paged, $period, $show_assets, $ctx_source );
		$paged  = isset( $detail['paged'] ) ? (int) $detail['paged'] : $paged;
		$color  = $this->purpose_color( $purpose );

		$period_labels = array(
			'1'   => __( '24 h', 'ai-visit-tracker' ),
			'7'   => __( '7 jours', 'ai-visit-tracker' ),
			'30'  => __( '30 jours', 'ai-visit-tracker' ),
			'90'  => __( '90 jours', 'ai-visit-tracker' ),
			'365' => __( '365 jours', 'ai-visit-tracker' ),
			'all' => __( 'Tout', 'ai-visit-tracker' ),
		);
		$period_label = isset( $period_labels[ $period ] ) ? $period_labels[ $period ] : __( 'Tout', 'ai-visit-tracker' );

		$max_src = 1;
		foreach ( $detail['by_source'] as $r ) {
			if ( $r['total'] > $max_src ) {
				$max_src = $r['total'];
			}
		}
		?>
		<div class="wrap aivt-app aivt-detailview">
			<a class="aivt-back" href="<?php echo esc_url( $list_url ); ?>"><?php $this->icon( 'back' ); ?> <?php esc_html_e( 'Retour au tableau de bord', 'ai-visit-tracker' ); ?></a>

			<header class="aivt-dethead">
				<div class="aivt-dethead-main">
					<span class="aivt-dethead-kicker"><span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span> <?php esc_html_e( 'Finalite', 'ai-visit-tracker' ); ?></span>
					<h1 class="aivt-dethead-url"><?php echo esc_html( $this->get_label( self::PURPOSE_LABELS, $purpose ) ); ?></h1>
					<?php if ( 'all' !== $period || $show_assets || '' !== $ctx_source ) : ?>
					<p class="aivt-dethead-ctx">
						<?php echo esc_html( $period_label ); ?>
						<?php if ( $show_assets ) : ?> &middot; <?php esc_html_e( 'Tout (assets inclus)', 'ai-visit-tracker' ); ?><?php endif; ?>
						<?php if ( '' !== $ctx_source ) : ?> &middot; <?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $ctx_source ) ); ?><?php endif; ?>
					</p>
					<?php endif; ?>
				</div>
			</header>

			<section class="aivt-kpis" style="grid-template-columns:repeat(2,1fr);">
				<article class="aivt-kpi aivt-tone-indigo">
					<span class="aivt-kpi-icon"><?php $this->icon( 'pulse' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'Total visites', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['total'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['total'] ) ); ?></span>
				</article>
				<article class="aivt-kpi aivt-tone-violet">
					<span class="aivt-kpi-icon"><?php $this->icon( 'link' ); ?></span>
					<span class="aivt-kpi-label"><?php esc_html_e( 'URLs distinctes', 'ai-visit-tracker' ); ?></span>
					<span class="aivt-kpi-value" data-count="<?php echo esc_attr( $detail['stats']['urls'] ); ?>"><?php echo esc_html( number_format_i18n( $detail['stats']['urls'] ) ); ?></span>
				</article>
			</section>

			<?php if ( ! empty( $detail['by_source'] ) ) : ?>
			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'cpu' ); ?> <?php esc_html_e( 'Plateformes pour cette finalité', 'ai-visit-tracker' ); ?></h2>
				</div>
				<ul class="aivt-rank">
					<?php
					// Contexte propage vers le detail source : la finalite courante
					// devient le filtre croise (les compteurs cliques correspondent).
					$src_ctx = array(
						'period'  => $period,
						'purpose' => $purpose,
					);
					if ( $show_assets ) {
						$src_ctx['show_assets'] = '1';
					}
					foreach ( $detail['by_source'] as $row ) :
						$src_url = add_query_arg(
							array_merge(
								array(
									'page'   => self::ADMIN_SLUG,
									'view'   => 'detail_source',
									'source' => $row['ai_source'],
								),
								$src_ctx
							),
							admin_url( 'admin.php' )
						);
						$scolor = $this->source_color( $row['ai_source'] );
						$pct    = ( $row['total'] / $max_src ) * 100;
						?>
						<li class="aivt-rank-item">
							<a class="aivt-rank-link" href="<?php echo esc_url( $src_url ); ?>">
								<span class="aivt-dot" style="--c: <?php echo esc_attr( $scolor ); ?>"></span>
								<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::SOURCE_LABELS, $row['ai_source'] ) ); ?></span>
								<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
							</a>
							<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $scolor ); ?>"></span></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
			<?php endif; ?>

			<section class="aivt-panel">
				<div class="aivt-panel-head">
					<h2><?php $this->icon( 'link' ); ?> <?php esc_html_e( 'Top URLs pour cette finalité', 'ai-visit-tracker' ); ?></h2>
				</div>
				<?php $this->render_top_urls_table( $detail, $paged ); ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Affiche une notice de succès après purge si présente dans la query string.
	 *
	 * @return void
	 */
	private function render_purge_notice() {
		if ( ! isset( $_GET['purged'] ) ) {
			return;
		}
		$purged = sanitize_key( wp_unslash( $_GET['purged'] ) );
		$msg    = '';
		if ( 'all' === $purged ) {
			$msg = __( 'Toutes les visites IA ont été supprimées.', 'ai-visit-tracker' );
		} elseif ( 'url' === $purged ) {
			$msg = __( 'Les visites de cette URL ont été supprimées.', 'ai-visit-tracker' );
		}
		if ( '' !== $msg ) {
			echo '<div class="aivt-notice">';
			$this->icon( 'check' );
			echo '<span>' . esc_html( $msg ) . '</span></div>';
		}
	}

	/**
	 * Rend une pagination stylée (réutilise paginate_links).
	 *
	 * @param int $total
	 * @param int $total_pages
	 * @param int $current
	 * @return void
	 */
	private function render_pagination( $total, $total_pages, $current ) {
		if ( $total_pages <= 1 ) {
			return;
		}
		?>
		<div class="aivt-pagination">
			<span class="aivt-page-info">
				<?php
				printf(
					/* translators: %s: number */
					esc_html( _n( '%s entrée', '%s entrées', $total, 'ai-visit-tracker' ) ),
					esc_html( number_format_i18n( $total ) )
				);
				?>
			</span>
			<span class="aivt-page-links">
				<?php
				echo wp_kses_post( paginate_links( array(
					'base'      => add_query_arg( 'paged', '%#%' ),
					'format'    => '',
					'total'     => $total_pages,
					'current'   => $current,
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
					'type'      => 'plain',
				) ) );
				?>
			</span>
		</div>
		<?php
	}

	/**
	 * Couleur d'accent de marque d'une source (fallback accent UI).
	 *
	 * @param string $source
	 * @return string
	 */
	private function source_color( $source ) {
		return isset( self::SOURCE_COLORS[ $source ] ) ? self::SOURCE_COLORS[ $source ] : '#6366f1';
	}

	/**
	 * Couleur d'accent d'une finalité (fallback accent UI).
	 *
	 * @param string $purpose
	 * @return string
	 */
	private function purpose_color( $purpose ) {
		return isset( self::PURPOSE_COLORS[ $purpose ] ) ? self::PURPOSE_COLORS[ $purpose ] : '#6366f1';
	}

	/**
	 * Rend un classement de finalités (liste à barres), chaque ligne pointant
	 * vers la page dédiée de la finalité. Réutilisé dans les vues détail.
	 *
	 * @param array<int,array<string,mixed>> $by_purpose
	 * @return void
	 */
	private function render_purpose_rank( $by_purpose ) {
		if ( empty( $by_purpose ) ) {
			$this->render_empty( __( 'Aucune finalité.', 'ai-visit-tracker' ) );
			return;
		}
		$max = 1;
		foreach ( $by_purpose as $r ) {
			if ( $r['total'] > $max ) {
				$max = $r['total'];
			}
		}
		?>
		<ul class="aivt-rank">
			<?php foreach ( $by_purpose as $row ) :
				$purpose_url = add_query_arg(
					array(
						'page'    => self::ADMIN_SLUG,
						'view'    => 'detail_purpose',
						'purpose' => $row['ai_purpose'],
					),
					admin_url( 'admin.php' )
				);
				$color = $this->purpose_color( $row['ai_purpose'] );
				$pct   = ( $row['total'] / $max ) * 100;
				?>
				<li class="aivt-rank-item">
					<a class="aivt-rank-link" href="<?php echo esc_url( $purpose_url ); ?>">
						<span class="aivt-dot" style="--c: <?php echo esc_attr( $color ); ?>"></span>
						<span class="aivt-rank-name"><?php echo esc_html( $this->get_label( self::PURPOSE_LABELS, $row['ai_purpose'] ) ); ?></span>
						<span class="aivt-rank-count"><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></span>
					</a>
					<span class="aivt-rank-bar"><span class="aivt-rank-fill" style="--w: <?php echo esc_attr( $pct ); ?>%; --c: <?php echo esc_attr( $color ); ?>"></span></span>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Nom d'icône associé à un type de contenu (fallback 'dot').
	 *
	 * @param string $type
	 * @return string
	 */
	private function content_icon( $type ) {
		return isset( self::CONTENT_TYPE_ICONS[ $type ] ) ? self::CONTENT_TYPE_ICONS[ $type ] : 'dot';
	}

	/**
	 * Rend un badge coloré de finalité de crawl.
	 *
	 * @param string $purpose
	 * @return void
	 */
	private function render_purpose_badge( $purpose ) {
		$tone  = isset( self::PURPOSE_TONES[ $purpose ] ) ? self::PURPOSE_TONES[ $purpose ] : '';
		$label = $this->get_label( self::PURPOSE_LABELS, $purpose );
		$class = 'aivt-badge' . ( '' !== $tone ? ' aivt-badge-' . $tone : '' );
		echo '<span class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Rend le graphique d'activité (barres CSS animées).
	 *
	 * @param array<int,array<string,mixed>> $histogram
	 * @param int                            $max_hist
	 * @return void
	 */
	private function render_chart( $histogram, $max_hist ) {
		$count = count( $histogram );
		// Espacement adaptatif : resserre les barres quand l'historique est long.
		$gap = $count > 150 ? 1 : ( $count > 70 ? 2 : 3 );
		?>
		<div class="aivt-chart" role="img" style="--gap: <?php echo (int) $gap; ?>px" aria-label="<?php esc_attr_e( 'Histogramme des visites IA', 'ai-visit-tracker' ); ?>">
			<?php
			$i = 0;
			foreach ( $histogram as $row ) :
				$pct  = ( $row['total'] / $max_hist ) * 100;
				$nice = mysql2date( 'j M', $row['log_date'] . ' 00:00:00' );
				?>
				<div class="aivt-chart-col" style="--i: <?php echo (int) $i; ?>">
					<span class="aivt-chart-tip"><strong><?php echo esc_html( number_format_i18n( $row['total'] ) ); ?></strong><?php echo esc_html( $nice ); ?></span>
					<span class="aivt-chart-bar" style="--h: <?php echo esc_attr( max( $pct, 0 ) ); ?>%"></span>
				</div>
				<?php
				$i++;
			endforeach;
			?>
		</div>
		<?php
		if ( $count > 1 ) :
			$first = mysql2date( 'j M', $histogram[0]['log_date'] . ' 00:00:00' );
			$last  = mysql2date( 'j M', $histogram[ $count - 1 ]['log_date'] . ' 00:00:00' );
			?>
			<div class="aivt-chart-axis"><span><?php echo esc_html( $first ); ?></span><span><?php echo esc_html( $last ); ?></span></div>
			<?php
		endif;
	}

	/**
	 * Rend un état vide compact (dans un panel).
	 *
	 * @param string $message
	 * @return void
	 */
	private function render_empty( $message ) {
		?>
		<div class="aivt-empty">
			<span class="aivt-empty-ico"><?php $this->icon( 'ghost' ); ?></span>
			<p><?php echo esc_html( $message ); ?></p>
		</div>
		<?php
	}

	/**
	 * Rend un état pleine page (erreur / introuvable) avec retour.
	 *
	 * @param string $title
	 * @param string $message
	 * @param string $back_url
	 * @param string $icon
	 * @return void
	 */
	private function render_state( $title, $message, $back_url, $icon ) {
		?>
		<div class="wrap aivt-app">
			<div class="aivt-state">
				<span class="aivt-state-ico"><?php $this->icon( $icon ); ?></span>
				<h1><?php echo esc_html( $title ); ?></h1>
				<p><?php echo esc_html( $message ); ?></p>
				<a class="aivt-btn aivt-btn-ghost" href="<?php echo esc_url( $back_url ); ?>"><?php $this->icon( 'back' ); ?><span><?php esc_html_e( 'Retour au tableau de bord', 'ai-visit-tracker' ); ?></span></a>
			</div>
		</div>
		<?php
	}

	/**
	 * Rend une icône SVG inline depuis un set statique et sûr.
	 *
	 * @param string $name Clé d'icône (fallback 'dot' si inconnue).
	 * @return void
	 */
	private function icon( $name ) {
		$paths = array(
			'cpu'      => '<rect x="5" y="5" width="14" height="14" rx="3"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
			'pulse'    => '<path d="M3 12h4l2.5 7 4-14 2.5 7H21"/>',
			'calendar' => '<rect x="3" y="4.5" width="18" height="16.5" rx="2.5"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
			'chart'    => '<path d="M3 21h18"/><rect x="5" y="11" width="3.2" height="7" rx="1"/><rect x="10.4" y="6" width="3.2" height="12" rx="1"/><rect x="15.8" y="9" width="3.2" height="9" rx="1"/>',
			'sigma'    => '<path d="M17.5 5.5V4H6.5l6.5 8-6.5 8h11v-1.5"/>',
			'layers'   => '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
			'link'     => '<path d="M9.5 13.5a4 4 0 0 0 6 .5l3-3a4 4 0 0 0-5.6-5.6l-1.3 1.2"/><path d="M14.5 10.5a4 4 0 0 0-6-.5l-3 3a4 4 0 0 0 5.6 5.6l1.2-1.2"/>',
			'trash'    => '<path d="M4 7h16M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M18 7l-1 13a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 7M10 11v6M14 11v6"/>',
			'filter'   => '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>',
			'close'    => '<path d="M6 6l12 12M18 6L6 18"/>',
			'back'     => '<path d="M15 5l-7 7 7 7"/>',
			'external' => '<path d="M14 4h6v6M20 4l-8.5 8.5M18 13.5V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5.5"/>',
			'check'    => '<path d="M20 6L9 17l-5-5"/>',
			'ghost'    => '<path d="M5 20.5V11a7 7 0 0 1 14 0v9.5l-3-2-2 2-2-2-2 2-3-2z"/><path d="M9.5 10.5h.01M14.5 10.5h.01"/>',
			'home'     => '<path d="M3 11l9-7.5 9 7.5M5.5 9.5V20h13V9.5"/>',
			'tag'      => '<path d="M3.5 3.5h7.5L21 13.5l-7.5 7.5L3.5 11z"/><circle cx="7.5" cy="7.5" r="1.3"/>',
			'doc'      => '<path d="M14 3H6.5A1.5 1.5 0 0 0 5 4.5v15A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3v5h5M8.5 13h7M8.5 17h5"/>',
			'page'     => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
			'user'     => '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
			'grid'     => '<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>',
			'folder'   => '<path d="M3.5 7a2 2 0 0 1 2-2h3.5l2 2H18.5a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
			'archive'  => '<rect x="3.5" y="4" width="17" height="4" rx="1"/><path d="M5.5 8v10.5a1.5 1.5 0 0 0 1.5 1.5h10a1.5 1.5 0 0 0 1.5-1.5V8M10 12h4"/>',
			'alert'    => '<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
			'code'     => '<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
			'target'   => '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.2"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/>',
			'dot'      => '<circle cx="12" cy="12" r="3.5"/>',
			'download' => '<path d="M12 3v12M7 11l5 5 5-5"/><path d="M5 19h14"/>',
		);
		$d = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['dot'];
		// SVG statique de confiance : aucune donnée utilisateur.
		echo '<svg class="aivt-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $d . '</svg>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	// ============================================================
	// Queries
	// ============================================================

	/**
	 * Retourne les sources reellement presentes en base (pour le menu deroulant).
	 *
	 * Triees par libelle via SOURCE_LABELS. La source active (meme absente des
	 * donnees) est toujours incluse pour eviter de casser un lien existant.
	 *
	 * @param string $active_source Source couramment selectionnee.
	 * @return array<string,string> Tableau source_key => label.
	 */
	private function get_active_sources( $active_source = '' ) {
		global $wpdb;
		$table = $this->get_table_name();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT DISTINCT ai_source FROM {$table} ORDER BY ai_source ASC", ARRAY_A );

		$keys = array();
		foreach ( (array) $rows as $r ) {
			$keys[] = (string) $r['ai_source'];
		}
		// Inclure la source active meme si elle a disparu des donnees.
		if ( '' !== $active_source && ! in_array( $active_source, $keys, true ) ) {
			$keys[] = $active_source;
		}

		// Trier par libelle via SOURCE_LABELS.
		usort( $keys, function ( $a, $b ) {
			$la = isset( self::SOURCE_LABELS[ $a ] ) ? self::SOURCE_LABELS[ $a ] : $a;
			$lb = isset( self::SOURCE_LABELS[ $b ] ) ? self::SOURCE_LABELS[ $b ] : $b;
			return strcmp( $la, $lb );
		} );

		$out = array();
		foreach ( $keys as $key ) {
			$out[ $key ] = isset( self::SOURCE_LABELS[ $key ] ) ? self::SOURCE_LABELS[ $key ] : $key;
		}
		return $out;
	}

	/**
	 * Construit les fragments WHERE pour les filtres communs (assets, source, finalite).
	 *
	 * Retourne conditions et params SEPARES pour permettre a get_global_stats()
	 * de prefixer ses propres params de dates avant de fusionner.
	 *
	 * @param string $source         Source canonique a filtrer ('' = aucune).
	 * @param string $purpose        Finalite a filtrer ('' = aucune).
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @return array{conditions:array<string>,params:array<string>}
	 */
	private function build_filters_where( $source = '', $purpose = '', $include_assets = true ) {
		$conditions = array();
		$params     = array();
		if ( ! $include_assets ) {
			$conditions[] = 'is_asset = 0';
		}
		if ( '' !== $source && isset( self::SOURCE_LABELS[ $source ] ) ) {
			$conditions[] = 'ai_source = %s';
			$params[]     = $source;
		}
		if ( '' !== $purpose && isset( self::PURPOSE_LABELS[ $purpose ] ) ) {
			$conditions[] = 'ai_purpose = %s';
			$params[]     = $purpose;
		}
		return array(
			'conditions' => $conditions,
			'params'     => $params,
		);
	}

	/**
	 * Stats globales (24h, 7j, 30j, total), filtrables par source et finalité.
	 *
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @param string $source         Source canonique pour filtrer ('' = aucune).
	 * @param string $purpose        Finalité pour filtrer ('' = aucune).
	 * @return array<string,int>
	 */
	private function get_global_stats( $include_assets = false, $source = '', $purpose = '' ) {
		global $wpdb;
		$table = $this->get_table_name();

		$today_start = current_time( 'Y-m-d' ) . ' 00:00:00';
		$d7          = $this->period_start( 7 );
		$d30         = $this->period_start( 30 );

		$filters   = $this->build_filters_where( $source, $purpose, $include_assets );
		$where_sql = $filters['conditions'] ? ' WHERE ' . implode( ' AND ', $filters['conditions'] ) : '';
		// Les 3 params de dates sont PREFIXES aux params de filtres.
		$params    = array_merge( array( $today_start, $d7, $d30 ), $filters['params'] );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT
				COALESCE(SUM(CASE WHEN visit_at >= %s THEN 1 ELSE 0 END), 0) AS bot_24h,
				COALESCE(SUM(CASE WHEN visit_at >= %s THEN 1 ELSE 0 END), 0) AS bot_7d,
				COALESCE(SUM(CASE WHEN visit_at >= %s THEN 1 ELSE 0 END), 0) AS bot_30d,
				COUNT(*) AS bot_total
			 FROM {$table}{$where_sql}",
			$params
		), ARRAY_A );

		if ( ! $row ) {
			$row = array();
		}
		return array(
			'bot_24h'   => isset( $row['bot_24h'] ) ? (int) $row['bot_24h'] : 0,
			'bot_7d'    => isset( $row['bot_7d'] ) ? (int) $row['bot_7d'] : 0,
			'bot_30d'   => isset( $row['bot_30d'] ) ? (int) $row['bot_30d'] : 0,
			'bot_total' => isset( $row['bot_total'] ) ? (int) $row['bot_total'] : 0,
		);
	}

	/**
	 * Agrégat par source IA sur les N derniers jours.
	 *
	 * Reflète tous les filtres actifs (source + finalité + assets) afin que le
	 * panneau colle à la sélection du tableau de bord.
	 *
	 * @param int    $days
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @param string $purpose        Finalité pour filtrer ('' = aucune).
	 * @param string $source         Source pour filtrer ('' = aucune).
	 * @return array<int,array<string,mixed>>
	 */
	private function get_source_breakdown( $days, $include_assets = false, $purpose = '', $source = '' ) {
		global $wpdb;
		$table  = $this->get_table_name();
		$start  = $this->period_start( $days );

		$filters   = $this->build_filters_where( $source, $purpose, $include_assets );
		$where     = array_merge( array( 'visit_at >= %s' ), $filters['conditions'] );
		$params    = array_merge( array( $start ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_source,
				COUNT(*) AS total,
				MAX(visit_at) AS last_seen
			 FROM {$table}
			 {$where_sql}
			 GROUP BY ai_source
			 ORDER BY total DESC",
			$params
		), ARRAY_A );

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'ai_source' => (string) $r['ai_source'],
				'total'     => (int) $r['total'],
				'last_seen' => (string) $r['last_seen'],
			);
		}
		return $out;
	}

	/**
	 * Agrégat par finalité sur les N derniers jours.
	 *
	 * Reflète tous les filtres actifs (source + finalité + assets) afin que le
	 * panneau colle à la sélection du tableau de bord.
	 *
	 * @param int    $days
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @param string $source         Source canonique pour filtrer ('' = aucune).
	 * @param string $purpose        Finalité pour filtrer ('' = aucune).
	 * @return array<int,array<string,mixed>>
	 */
	private function get_purpose_breakdown( $days, $include_assets = false, $source = '', $purpose = '' ) {
		global $wpdb;
		$table  = $this->get_table_name();
		$start  = $this->period_start( $days );

		$filters   = $this->build_filters_where( $source, $purpose, $include_assets );
		$where     = array_merge( array( 'visit_at >= %s' ), $filters['conditions'] );
		$params    = array_merge( array( $start ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_purpose,
				COUNT(*) AS total,
				MAX(visit_at) AS last_seen
			 FROM {$table}
			 {$where_sql}
			 GROUP BY ai_purpose
			 ORDER BY total DESC",
			$params
		), ARRAY_A );

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'ai_purpose' => (string) $r['ai_purpose'],
				'total'      => (int) $r['total'],
				'last_seen'  => (string) $r['last_seen'],
			);
		}
		return $out;
	}

	/**
	 * Top URLs paginées sur la période, optionnellement filtrées par source.
	 *
	 * @param int    $days
	 * @param int    $paged          Numéro de page (≥ 1).
	 * @param int    $per_page
	 * @param string $source         Source canonique pour filtrer ('' = aucune).
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @param string $purpose        Finalité pour filtrer ('' = aucune).
	 * @return array{rows:array<int,array<string,mixed>>,total:int,total_pages:int}
	 */
	private function get_top_urls_paged( $days, $paged, $per_page, $source = '', $include_assets = false, $purpose = '' ) {
		global $wpdb;
		$table  = $this->get_table_name();
		$start  = $this->period_start( $days );
		$paged  = max( 1, (int) $paged );

		$filters   = $this->build_filters_where( $source, $purpose, $include_assets );
		$where     = array_merge( array( 'visit_at >= %s' ), $filters['conditions'] );
		$params    = array_merge( array( $start ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// Total : nombre d'URLs distinctes sur la période
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(DISTINCT url_hash) FROM {$table} {$where_sql}",
			$params
		) );

		$total_pages = (int) ceil( $total / $per_page );
		// Cap $paged contre $total_pages (évite OFFSET énormes sur ?paged=99999)
		if ( $total_pages > 0 && $paged > $total_pages ) {
			$paged = $total_pages;
		}
		$offset = ( $paged - 1 ) * $per_page;

		$params_with_lim = array_merge( $params, array( $per_page, $offset ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT url, url_hash, COUNT(*) AS visits, MAX(visit_at) AS last_seen
			 FROM {$table}
			 {$where_sql}
			 GROUP BY url_hash, url
			 ORDER BY visits DESC, last_seen DESC
			 LIMIT %d OFFSET %d",
			$params_with_lim
		), ARRAY_A );

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'url'       => (string) $r['url'],
				'url_hash'  => (string) $r['url_hash'],
				'visits'    => (int) $r['visits'],
				'last_seen' => (string) $r['last_seen'],
			);
		}

		return array(
			'rows'        => $out,
			'total'       => $total,
			'total_pages' => $total_pages,
		);
	}

	/**
	 * Visibilité par type de contenu (produit, article, page, auteur…).
	 *
	 * @param int    $days
	 * @param string $source
	 * @param string $purpose Finalité pour filtrer ('' = aucune).
	 * @return array<int,array<string,mixed>>
	 */
	private function get_content_visibility( $days, $source, $purpose = '' ) {
		global $wpdb;
		$table = $this->get_table_name();
		$start = $this->period_start( $days );

		// is_asset = 0 : le panneau « contenu » reste propre ; les fichiers
		// techniques sont comptés séparément (cf. get_asset_summary()).
		// build_filters_where avec include_assets=false garantit is_asset=0.
		$filters   = $this->build_filters_where( $source, $purpose, false );
		$where     = array_merge( array( 'visit_at >= %s', 'content_type IS NOT NULL' ), $filters['conditions'] );
		$params    = array_merge( array( $start ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT content_type,
				COUNT(*) AS visits,
				COUNT(DISTINCT url_hash) AS urls,
				MAX(visit_at) AS last_seen
			 FROM {$table}
			 {$where_sql}
			 GROUP BY content_type
			 ORDER BY visits DESC",
			$params
		), ARRAY_A );

		$out = array();
		foreach ( (array) $rows as $r ) {
			$out[] = array(
				'content_type' => (string) $r['content_type'],
				'visits'       => (int) $r['visits'],
				'urls'         => (int) $r['urls'],
				'last_seen'    => (string) $r['last_seen'],
			);
		}
		return $out;
	}

	/**
	 * Résumé des fichiers techniques (is_asset=1) sur la période, pour la
	 * ligne « awareness » du panneau contenu.
	 *
	 * @param int    $days
	 * @param string $source
	 * @param string $purpose Finalité pour filtrer ('' = aucune).
	 * @return array{visits:int,urls:int,last_seen:string}
	 */
	private function get_asset_summary( $days, $source, $purpose = '' ) {
		global $wpdb;
		$table = $this->get_table_name();
		$start = $this->period_start( $days );

		// Seul is_asset = 1 compte ici : on passe include_assets=true et on force
		// la condition manuellement, pour ne pas que build_filters_where ajoute is_asset=0.
		$filters   = $this->build_filters_where( $source, $purpose, true );
		$where     = array_merge( array( 'visit_at >= %s', 'is_asset = 1' ), $filters['conditions'] );
		$params    = array_merge( array( $start ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS visits, COUNT(DISTINCT url_hash) AS urls, MAX(visit_at) AS last_seen
			 FROM {$table}
			 {$where_sql}",
			$params
		), ARRAY_A );

		return array(
			'visits'    => isset( $row['visits'] ) ? (int) $row['visits'] : 0,
			'urls'      => isset( $row['urls'] ) ? (int) $row['urls'] : 0,
			'last_seen' => isset( $row['last_seen'] ) ? (string) $row['last_seen'] : '',
		);
	}

	/**
	 * Histogramme par jour sur N jours, complété pour les jours sans hit.
	 *
	 * @param int    $days
	 * @param bool   $include_assets Inclure les fichiers techniques (is_asset=1).
	 * @param string $source         Source canonique pour filtrer ('' = aucune).
	 * @param string $purpose        Finalité pour filtrer ('' = aucune).
	 * @return array<int,array<string,mixed>>
	 */
	private function get_histogram( $days, $include_assets = false, $source = '', $purpose = '' ) {
		global $wpdb;
		$table = $this->get_table_name();
		$start_date = wp_date( 'Y-m-d', time() - ( $days - 1 ) * DAY_IN_SECONDS );

		$filters   = $this->build_filters_where( $source, $purpose, $include_assets );
		$where     = array_merge( array( 'visit_at >= %s' ), $filters['conditions'] );
		$params    = array_merge( array( $start_date . ' 00:00:00' ), $filters['params'] );
		$where_sql = 'WHERE ' . implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT DATE(visit_at) AS log_date, COUNT(*) AS total
			 FROM {$table}
			 {$where_sql}
			 GROUP BY DATE(visit_at)
			 ORDER BY log_date ASC",
			$params
		), ARRAY_A );

		$by_date = array();
		foreach ( (array) $rows as $r ) {
			$by_date[ $r['log_date'] ] = $r;
		}

		$out = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$date  = wp_date( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
			$out[] = array(
				'log_date' => $date,
				'total'    => isset( $by_date[ $date ] ) ? (int) $by_date[ $date ]['total'] : 0,
			);
		}
		return $out;
	}

	/**
	 * Détail d'une URL : URL, stats, breakdown par source, hits paginés.
	 *
	 * @param string $url_hash
	 * @param int    $paged
	 * @return array<string,mixed>
	 */
	private function get_url_detail_data( $url_hash, $paged ) {
		global $wpdb;
		$table    = $this->get_table_name();
		$per_page = 50;
		$paged    = max( 1, (int) $paged );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$stats_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT MAX(url) AS url,
				COUNT(*) AS total,
				MIN(visit_at) AS first_seen,
				MAX(visit_at) AS last_seen
			 FROM {$table}
			 WHERE url_hash = %s",
			$url_hash
		), ARRAY_A );

		$url         = isset( $stats_row['url'] ) ? (string) $stats_row['url'] : '';
		$total       = isset( $stats_row['total'] ) ? (int) $stats_row['total'] : 0;
		$total_pages = (int) ceil( $total / $per_page );
		// Cap $paged contre $total_pages
		if ( $total_pages > 0 && $paged > $total_pages ) {
			$paged = $total_pages;
		}
		$offset = ( $paged - 1 ) * $per_page;

		if ( '' === $url || 0 === $total ) {
			return array(
				'url'         => '',
				'rows'        => array(),
				'by_source'   => array(),
				'by_purpose'  => array(),
				'total'       => 0,
				'total_pages' => 0,
				'stats'       => array(
					'total'      => 0,
					'first_seen' => '',
					'last_seen'  => '',
				),
			);
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$source_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_source, COUNT(*) AS total
			 FROM {$table}
			 WHERE url_hash = %s
			 GROUP BY ai_source
			 ORDER BY total DESC",
			$url_hash
		), ARRAY_A );

		$by_source = array();
		foreach ( (array) $source_rows as $r ) {
			$by_source[] = array(
				'ai_source' => (string) $r['ai_source'],
				'total'     => (int) $r['total'],
			);
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$purpose_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_purpose, COUNT(*) AS total
			 FROM {$table}
			 WHERE url_hash = %s
			 GROUP BY ai_purpose
			 ORDER BY total DESC",
			$url_hash
		), ARRAY_A );

		$by_purpose = array();
		foreach ( (array) $purpose_rows as $r ) {
			$by_purpose[] = array(
				'ai_purpose' => (string) $r['ai_purpose'],
				'total'      => (int) $r['total'],
			);
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT visit_at, ai_source, ai_label, ai_purpose, ip, user_agent, visit_type, verified
			 FROM {$table}
			 WHERE url_hash = %s
			 ORDER BY visit_at DESC, id DESC
			 LIMIT %d OFFSET %d",
			$url_hash, $per_page, $offset
		), ARRAY_A );

		$out_rows = array();
		foreach ( (array) $rows as $r ) {
			$out_rows[] = array(
				'visit_at'   => (string) $r['visit_at'],
				'ai_source'  => (string) $r['ai_source'],
				'ai_label'   => (string) $r['ai_label'],
				'ai_purpose' => (string) $r['ai_purpose'],
				'ip'         => (string) $r['ip'],
				'user_agent' => (string) $r['user_agent'],
				'visit_type' => (string) $r['visit_type'],
				'verified'   => isset( $r['verified'] ) && '' !== $r['verified'] ? (int) $r['verified'] : null,
			);
		}

		return array(
			'url'         => $url,
			'rows'        => $out_rows,
			'by_source'   => $by_source,
			'by_purpose'  => $by_purpose,
			'total'       => $total,
			'total_pages' => $total_pages,
			'paged'       => $paged,
			'stats'       => array(
				'total'      => $total,
				'first_seen' => (string) $stats_row['first_seen'],
				'last_seen'  => (string) $stats_row['last_seen'],
			),
		);
	}

	/**
	 * Détail d'une source IA : stats, finalites, top URLs paginées.
	 * Accepte des filtres contextuels propagés depuis le tableau de bord.
	 *
	 * @param string $source       Source canonique.
	 * @param int    $paged        Page courante.
	 * @param string $period       Periode : '1','7','30','90','365' ou 'all'.
	 * @param bool   $show_assets  Inclure les assets (true) ou les exclure (false).
	 * @param string $ctx_purpose  Filtre croise : finalite ('' = aucun).
	 * @return array<string,mixed>
	 */
	private function get_source_detail_data( $source, $paged, $period = 'all', $show_assets = false, $ctx_purpose = '' ) {
		global $wpdb;
		$table    = $this->get_table_name();
		$per_page = 50;
		$paged    = max( 1, (int) $paged );

		// Construire les conditions WHERE.
		// Source est le critere principal (cette vue), purpose et assets sont les filtres croises.
		$filters    = $this->build_filters_where( '', $ctx_purpose, $show_assets );
		$conditions = $filters['conditions'];
		$params     = $filters['params'];

		// Filtre principal : source.
		$conditions[] = 'ai_source = %s';
		$params[]     = $source;

		// Filtre periode.
		if ( 'all' !== $period && is_numeric( $period ) && (int) $period > 0 ) {
			$conditions[] = 'visit_at >= %s';
			$params[]     = $this->period_start( (int) $period );
		}

		$where_sql = 'WHERE ' . implode( ' AND ', $conditions );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$stats_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS total, COUNT(DISTINCT url_hash) AS urls FROM {$table} {$where_sql}",
			$params
		), ARRAY_A );

		$total_urls  = isset( $stats_row['urls'] ) ? (int) $stats_row['urls'] : 0;
		$total_pages = (int) ceil( $total_urls / $per_page );
		if ( $total_pages > 0 && $paged > $total_pages ) {
			$paged = $total_pages;
		}
		$offset = ( $paged - 1 ) * $per_page;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$purpose_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_purpose, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_purpose ORDER BY total DESC",
			$params
		), ARRAY_A );

		$by_purpose = array();
		foreach ( (array) $purpose_rows as $r ) {
			$by_purpose[] = array(
				'ai_purpose' => (string) $r['ai_purpose'],
				'total'      => (int) $r['total'],
			);
		}

		$url_params = array_merge( $params, array( $per_page, $offset ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT url, url_hash, COUNT(*) AS visits, MAX(visit_at) AS last_seen
			 FROM {$table} {$where_sql}
			 GROUP BY url_hash, url
			 ORDER BY visits DESC, last_seen DESC
			 LIMIT %d OFFSET %d",
			$url_params
		), ARRAY_A );

		$out_rows = array();
		foreach ( (array) $rows as $r ) {
			$out_rows[] = array(
				'url'       => (string) $r['url'],
				'url_hash'  => (string) $r['url_hash'],
				'visits'    => (int) $r['visits'],
				'last_seen' => (string) $r['last_seen'],
			);
		}

		return array(
			'rows'        => $out_rows,
			'by_purpose'  => $by_purpose,
			'total'       => $total_urls,
			'total_pages' => $total_pages,
			'paged'       => $paged,
			'stats'       => array(
				'total' => isset( $stats_row['total'] ) ? (int) $stats_row['total'] : 0,
				'urls'  => $total_urls,
			),
		);
	}

	/**
	 * Détail d'un type de contenu : stats, breakdown par source et finalite, top URLs.
	 * Accepte des filtres contextuels propagés depuis le tableau de bord.
	 *
	 * @param string $content_type  Type de contenu (ou 'asset' pour la vue virtuelle).
	 * @param int    $paged         Page courante.
	 * @param string $period        Periode : '1','7','30','90','365' ou 'all'.
	 * @param string $ctx_source    Filtre croise : source ('' = aucun).
	 * @param string $ctx_purpose   Filtre croise : finalite ('' = aucun).
	 * @return array<string,mixed>
	 */
	private function get_content_detail_data( $content_type, $paged, $period = 'all', $ctx_source = '', $ctx_purpose = '' ) {
		global $wpdb;
		$table    = $this->get_table_name();
		$per_page = 50;
		$paged    = max( 1, (int) $paged );

		// Type virtuel « asset » => filtre sur is_asset plutot que content_type.
		// Les types normaux excluent TOUJOURS les assets : le panneau contenu du
		// tableau de bord les compte a part (cf. get_asset_summary()), donc les
		// compteurs cliques correspondent, bascule « Tout » comprise.
		$is_asset_view = ( 'asset' === $content_type );

		// Construire les conditions WHERE.
		$conditions = array();
		$params     = array();

		if ( $is_asset_view ) {
			$conditions[] = 'is_asset = 1';
		} else {
			$conditions[] = 'content_type = %s';
			$params[]     = $content_type;
			$conditions[] = 'is_asset = 0';
		}

		// Filtres croises.
		if ( '' !== $ctx_source && isset( self::SOURCE_LABELS[ $ctx_source ] ) ) {
			$conditions[] = 'ai_source = %s';
			$params[]     = $ctx_source;
		}
		if ( '' !== $ctx_purpose && isset( self::PURPOSE_LABELS[ $ctx_purpose ] ) ) {
			$conditions[] = 'ai_purpose = %s';
			$params[]     = $ctx_purpose;
		}

		// Filtre periode.
		if ( 'all' !== $period && is_numeric( $period ) && (int) $period > 0 ) {
			$conditions[] = 'visit_at >= %s';
			$params[]     = $this->period_start( (int) $period );
		}

		$where_sql = 'WHERE ' . implode( ' AND ', $conditions );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$stats_row = empty( $params )
			? $wpdb->get_row( "SELECT COUNT(*) AS total, COUNT(DISTINCT url_hash) AS urls FROM {$table} {$where_sql}", ARRAY_A )
			: $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total, COUNT(DISTINCT url_hash) AS urls FROM {$table} {$where_sql}", $params ), ARRAY_A );

		$total_urls  = isset( $stats_row['urls'] ) ? (int) $stats_row['urls'] : 0;
		$total_pages = (int) ceil( $total_urls / $per_page );
		if ( $total_pages > 0 && $paged > $total_pages ) {
			$paged = $total_pages;
		}
		$offset = ( $paged - 1 ) * $per_page;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$source_rows = empty( $params )
			? $wpdb->get_results( "SELECT ai_source, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_source ORDER BY total DESC", ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( "SELECT ai_source, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_source ORDER BY total DESC", $params ), ARRAY_A );

		$by_source = array();
		foreach ( (array) $source_rows as $r ) {
			$by_source[] = array(
				'ai_source' => (string) $r['ai_source'],
				'total'     => (int) $r['total'],
			);
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$purpose_rows = empty( $params )
			? $wpdb->get_results( "SELECT ai_purpose, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_purpose ORDER BY total DESC", ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( "SELECT ai_purpose, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_purpose ORDER BY total DESC", $params ), ARRAY_A );

		$by_purpose = array();
		foreach ( (array) $purpose_rows as $r ) {
			$by_purpose[] = array(
				'ai_purpose' => (string) $r['ai_purpose'],
				'total'      => (int) $r['total'],
			);
		}

		$url_params = array_merge( $params, array( $per_page, $offset ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT url, url_hash, COUNT(*) AS visits, MAX(visit_at) AS last_seen
			 FROM {$table} {$where_sql}
			 GROUP BY url_hash, url
			 ORDER BY visits DESC, last_seen DESC
			 LIMIT %d OFFSET %d",
			$url_params
		), ARRAY_A );

		$out_rows = array();
		foreach ( (array) $rows as $r ) {
			$out_rows[] = array(
				'url'       => (string) $r['url'],
				'url_hash'  => (string) $r['url_hash'],
				'visits'    => (int) $r['visits'],
				'last_seen' => (string) $r['last_seen'],
			);
		}

		return array(
			'rows'        => $out_rows,
			'by_source'   => $by_source,
			'by_purpose'  => $by_purpose,
			'total'       => $total_urls,
			'total_pages' => $total_pages,
			'paged'       => $paged,
			'stats'       => array(
				'total' => isset( $stats_row['total'] ) ? (int) $stats_row['total'] : 0,
				'urls'  => $total_urls,
			),
		);
	}

	/**
	 * Détail d'une finalite : stats, breakdown par source, top URLs.
	 * Accepte des filtres contextuels propagés depuis le tableau de bord.
	 *
	 * @param string $purpose      Finalite canonique.
	 * @param int    $paged        Page courante.
	 * @param string $period       Periode : '1','7','30','90','365' ou 'all'.
	 * @param bool   $show_assets  Inclure les assets (true) ou les exclure (false).
	 * @param string $ctx_source   Filtre croise : source ('' = aucun).
	 * @return array<string,mixed>
	 */
	private function get_purpose_detail_data( $purpose, $paged, $period = 'all', $show_assets = false, $ctx_source = '' ) {
		global $wpdb;
		$table    = $this->get_table_name();
		$per_page = 50;
		$paged    = max( 1, (int) $paged );

		// Construire les conditions WHERE.
		$filters    = $this->build_filters_where( $ctx_source, '', $show_assets );
		$conditions = $filters['conditions'];
		$params     = $filters['params'];

		// Filtre principal : finalite.
		$conditions[] = 'ai_purpose = %s';
		$params[]     = $purpose;

		// Filtre periode.
		if ( 'all' !== $period && is_numeric( $period ) && (int) $period > 0 ) {
			$conditions[] = 'visit_at >= %s';
			$params[]     = $this->period_start( (int) $period );
		}

		$where_sql = 'WHERE ' . implode( ' AND ', $conditions );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$stats_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS total, COUNT(DISTINCT url_hash) AS urls FROM {$table} {$where_sql}",
			$params
		), ARRAY_A );

		$total_urls  = isset( $stats_row['urls'] ) ? (int) $stats_row['urls'] : 0;
		$total_pages = (int) ceil( $total_urls / $per_page );
		if ( $total_pages > 0 && $paged > $total_pages ) {
			$paged = $total_pages;
		}
		$offset = ( $paged - 1 ) * $per_page;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$source_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ai_source, COUNT(*) AS total FROM {$table} {$where_sql} GROUP BY ai_source ORDER BY total DESC",
			$params
		), ARRAY_A );

		$by_source = array();
		foreach ( (array) $source_rows as $r ) {
			$by_source[] = array(
				'ai_source' => (string) $r['ai_source'],
				'total'     => (int) $r['total'],
			);
		}

		$url_params = array_merge( $params, array( $per_page, $offset ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT url, url_hash, COUNT(*) AS visits, MAX(visit_at) AS last_seen
			 FROM {$table} {$where_sql}
			 GROUP BY url_hash, url
			 ORDER BY visits DESC, last_seen DESC
			 LIMIT %d OFFSET %d",
			$url_params
		), ARRAY_A );

		$out_rows = array();
		foreach ( (array) $rows as $r ) {
			$out_rows[] = array(
				'url'       => (string) $r['url'],
				'url_hash'  => (string) $r['url_hash'],
				'visits'    => (int) $r['visits'],
				'last_seen' => (string) $r['last_seen'],
			);
		}

		return array(
			'rows'        => $out_rows,
			'by_source'   => $by_source,
			'total'       => $total_urls,
			'total_pages' => $total_pages,
			'paged'       => $paged,
			'stats'       => array(
				'total' => isset( $stats_row['total'] ) ? (int) $stats_row['total'] : 0,
				'urls'  => $total_urls,
			),
		);
	}

	/**
	 * Poids de la table en octets et nombre de lignes exactes.
	 *
	 * Utilise information_schema.TABLES pour la taille (peut etre approximatif
	 * sur InnoDB entre deux ANALYZE TABLE, mais suffisant pour un indicateur
	 * discret). COUNT(*) donne le nombre exact de visites.
	 *
	 * @return array{bytes:int,rows:int}
	 */
	private function get_storage_footprint() {
		global $wpdb;
		$table     = $this->get_table_name();
		$db_name   = DB_NAME;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$size_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT (data_length + index_length) AS bytes FROM information_schema.TABLES WHERE table_schema = %s AND table_name = %s",
			$db_name,
			$table
		), ARRAY_A );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		return array(
			'bytes' => isset( $size_row['bytes'] ) ? (int) $size_row['bytes'] : 0,
			'rows'  => $count,
		);
	}

	/**
	 * Nombre de jours entre la première visite enregistrée et maintenant.
	 *
	 * @return int 0 si la table est vide.
	 */
	private function get_data_span_days() {
		global $wpdb;
		$table = $this->get_table_name();
		// current_time('mysql') utilise le fuseau horaire WP, coherent avec visit_at.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$span = $wpdb->get_var( $wpdb->prepare(
			"SELECT DATEDIFF(%s, MIN(visit_at)) FROM {$table}",
			current_time( 'mysql' )
		) );
		return null === $span ? 0 : max( 0, (int) $span );
	}

	// ============================================================
	// Helpers
	// ============================================================

	/**
	 * Borne temporelle pour requêtes (heure locale WP).
	 *
	 * @param int $days Nombre de jours en arrière (≥ 0).
	 * @return string Format Y-m-d H:i:s.
	 */
	private function period_start( $days ) {
		return wp_date( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	}

	/**
	 * Récupère un libellé d'affichage avec fallback sur la clé.
	 *
	 * @param array  $map
	 * @param string $key
	 * @return string
	 */
	private function get_label( $map, $key ) {
		return isset( $map[ $key ] ) ? $map[ $key ] : $key;
	}

	/**
	 * Formate un datetime stocké en heure LOCALE WP pour affichage.
	 *
	 * Utilise mysql2date() qui parse la string avec wp_timezone() : nécessaire
	 * pour éviter le double-shift (cf. changelog 0.1.1).
	 *
	 * @param string $datetime Format Y-m-d H:i:s (heure locale WP).
	 * @return string
	 */
	private function format_date( $datetime ) {
		if ( '' === $datetime ) {
			return '';
		}
		$formatted = mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $datetime );
		return false === $formatted ? $datetime : (string) $formatted;
	}

	// -------------------------------------------------------------------------
	// Updater distant
	// -------------------------------------------------------------------------

	/**
	 * Lit le manifest de mise a jour depuis le repo public (avec cache transient).
	 *
	 * En cas d'echec : transient courte duree (1 h) avec valeur sentinelle pour
	 * ne pas marteler GitHub. Retourne null si le manifest est invalide ou absent.
	 *
	 * @return array{version:string,package:string,url:string,requires:string,tested:string,requires_php:string}|null
	 */
	private function get_remote_manifest() {
		$cached = get_transient( self::UPDATE_CACHE_KEY );
		if ( false !== $cached ) {
			// Valeur sentinelle : echec precedent.
			if ( 'error' === $cached ) {
				return null;
			}
			return is_array( $cached ) ? $cached : null;
		}

		$resp = wp_safe_remote_get( self::MANIFEST_URL, array( 'timeout' => 5 ) );
		if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
			set_transient( self::UPDATE_CACHE_KEY, 'error', HOUR_IN_SECONDS );
			return null;
		}

		$body = (string) wp_remote_retrieve_body( $resp );
		$data = json_decode( $body, true );

		// Validation minimale : version et package obligatoires, package depuis le bon repo.
		$releases_prefix = 'https://raw.githubusercontent.com/CS-Digital-Suisse/ai-visit-tracker-releases/';
		if ( empty( $data['version'] ) || empty( $data['package'] ) ||
			0 !== strpos( $data['package'], $releases_prefix ) ) {
			set_transient( self::UPDATE_CACHE_KEY, 'error', HOUR_IN_SECONDS );
			return null;
		}

		$manifest = array(
			'version'      => (string) $data['version'],
			'package'      => (string) $data['package'],
			'url'          => isset( $data['url'] ) ? (string) $data['url'] : '',
			'requires'     => isset( $data['requires'] ) ? (string) $data['requires'] : '5.6',
			'tested'       => isset( $data['tested'] ) ? (string) $data['tested'] : '',
			'requires_php' => isset( $data['requires_php'] ) ? (string) $data['requires_php'] : '7.4',
		);

		set_transient( self::UPDATE_CACHE_KEY, $manifest, 12 * HOUR_IN_SECONDS );
		return $manifest;
	}

	/**
	 * Injecte les informations de mise a jour dans le mecanisme natif WordPress.
	 *
	 * Filtre : pre_set_site_transient_update_plugins (compatible WP 5.6).
	 *
	 * @param object $transient Transient WordPress des mises a jour de plugins.
	 * @return object
	 */
	public function inject_update_info( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		$basename = plugin_basename( AIVT_PLUGIN_FILE );
		$manifest = $this->get_remote_manifest();

		if ( null !== $manifest && version_compare( $manifest['version'], AIVT_VERSION, '>' ) ) {
			$update = (object) array(
				'slug'         => 'ai-visit-tracker',
				'plugin'       => $basename,
				'new_version'  => $manifest['version'],
				'package'      => $manifest['package'],
				'url'          => $manifest['url'],
				'tested'       => $manifest['tested'],
				'requires'     => $manifest['requires'],
				'requires_php' => $manifest['requires_php'],
			);
			$transient->response[ $basename ] = $update;
		} else {
			// Bonne pratique : inscrire dans no_update pour l'UI des auto-updates.
			$no_update = (object) array(
				'slug'        => 'ai-visit-tracker',
				'plugin'      => $basename,
				'new_version' => AIVT_VERSION,
				'url'         => isset( $manifest['url'] ) ? $manifest['url'] : '',
			);
			$transient->no_update[ $basename ] = $no_update;
		}

		return $transient;
	}

	/**
	 * Active les mises a jour automatiques pour ce plugin.
	 *
	 * Filtre : auto_update_plugin. Retourne true uniquement pour notre plugin,
	 * sans modifier la valeur pour les autres.
	 *
	 * @param bool|null $update Valeur courante du filtre.
	 * @param object    $item   Objet du plugin en cours d'evaluation.
	 * @return bool|null
	 */
	public function enable_auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && plugin_basename( AIVT_PLUGIN_FILE ) === $item->plugin ) {
			return true;
		}
		return $update;
	}

	/**
	 * Ajoute le lien « Verifier les mises a jour » dans la liste des extensions.
	 *
	 * @param array<string,string> $links Liens d'action existants.
	 * @return array<string,string>
	 */
	public function add_check_update_link( $links ) {
		$nonce_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=aivt_check_update' ),
			'aivt_check_update'
		);
		$check_link = '<a href="' . esc_url( $nonce_url ) . '">'
			. esc_html__( 'Verifier les mises a jour', 'ai-visit-tracker' )
			. '</a>';
		$links[] = $check_link;
		return $links;
	}

	/**
	 * Handler de la verification manuelle des mises a jour.
	 *
	 * Supprime le transient, force un check, puis redirige vers plugins.php
	 * avec les parametres de retour.
	 *
	 * @return void
	 */
	public function handle_check_update() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'Acces refuse.', 'ai-visit-tracker' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'aivt_check_update' );

		// Invalider le transient pour forcer une lecture fraiche du manifest.
		delete_transient( self::UPDATE_CACHE_KEY );

		// Forcer WordPress a re-verifier les mises a jour de plugins.
		wp_update_plugins();

		// Detecter si une mise a jour est disponible apres verification.
		$manifest    = $this->get_remote_manifest();
		$has_update  = ( null !== $manifest && version_compare( $manifest['version'], AIVT_VERSION, '>' ) ) ? '1' : '0';

		$redirect = add_query_arg(
			array(
				'aivt_checked' => '1',
				'aivt_update'  => $has_update,
			),
			admin_url( 'plugins.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Affiche une notice admin apres une verification manuelle de mise a jour.
	 *
	 * Uniquement sur plugins.php et si le parametre aivt_checked est present.
	 *
	 * @return void
	 */
	public function render_update_notice() {
		$screen = get_current_screen();
		if ( ! $screen || 'plugins' !== $screen->id ) {
			return;
		}
		if ( empty( $_GET['aivt_checked'] ) ) {
			return;
		}

		$has_update = ! empty( $_GET['aivt_update'] ) && '1' === $_GET['aivt_update'];
		if ( $has_update ) {
			$message = esc_html__( 'Verification effectuee : une mise a jour est disponible.', 'ai-visit-tracker' );
			$class   = 'notice notice-success';
		} else {
			$message = esc_html__( 'Verification effectuee : le plugin est a jour.', 'ai-visit-tracker' );
			$class   = 'notice notice-info';
		}
		echo '<div class="' . esc_attr( $class ) . '"><p>' . $message . '</p></div>';
	}

	/**
	 * Charge le CSS et le JS admin uniquement sur la page du tracker.
	 *
	 * @param string $hook_suffix Hook fourni par admin_enqueue_scripts.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		// add_menu_page() (page de niveau 1) cree des pages sous "toplevel_page_{slug}"
		if ( 'toplevel_page_' . self::ADMIN_SLUG !== $hook_suffix ) {
			return;
		}
		$fallback = defined( 'AIVT_VERSION' ) ? AIVT_VERSION : false;

		$css_path = AIVT_PLUGIN_DIR . 'assets/css/admin.css';
		$css_ver  = filemtime( $css_path );
		if ( false === $css_ver ) {
			$css_ver = $fallback;
		}

		$js_path = AIVT_PLUGIN_DIR . 'assets/js/admin.js';
		$js_ver  = filemtime( $js_path );
		if ( false === $js_ver ) {
			$js_ver = $fallback;
		}

		wp_enqueue_style(
			'aivt-admin',
			AIVT_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			$css_ver
		);
		wp_enqueue_script(
			'aivt-admin',
			AIVT_PLUGIN_URL . 'assets/js/admin.js',
			array(),
			$js_ver,
			true
		);
	}
}
