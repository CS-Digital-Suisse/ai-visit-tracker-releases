# AI Visit Tracker

Plugin WordPress autonome qui journalise les visites des **crawlers et bots
de plateformes** par detection du *User-Agent*, et fournit un tableau de bord
d'analyse dans **Visibilite IA** (menu de niveau 1).

Trois familles de plateformes couvertes :

- **Intelligence artificielle** : OpenAI, Anthropic, Google AI, Perplexity,
  Mistral, Cohere, You.com, Common Crawl, ByteDance, xAI, Kagi, Phind, Poe.
- **Moteurs de recherche** : Google, Bing / Microsoft, Apple, DuckDuckGo,
  Amazon Alexa, Yandex, Baidu, Seznam.
- **Reseaux sociaux et messageries** : Meta (Facebook), X (Twitter), LinkedIn,
  Pinterest, WhatsApp, Slack.

Sans dependance, sans librairie, sans reglage : on active, ca enregistre.
Concu pour etre reutilisable sur n'importe quel site WordPress.

---

## Ce que le plugin fait

- **Capture serveur** sur `template_redirect` (priorite 999) : chaque requete
  `GET`/`HEAD` dont le User-Agent correspond a un bot de plateforme connu est
  enregistree. Les visites humaines / non reconnues **ne sont pas** loggees.
- **50+ bots reconnus**, classes par famille (ia / search / social), par source
  et par finalite (entrainement, indexation, fetch utilisateur, agent,
  publicite, service technique, partage social).
- **Trois dimensions de filtrage** en faceting : famille de plateforme, source
  et finalite. Chaque filtre decoupe tout le tableau de bord sauf son propre
  panneau de repartition.
- **Panneau Familles de plateformes** : classement des 3 familles avec clic
  pour filtrer. Derive du breakdown par source, aucune requete SQL
  supplementaire.
- **Detection du type de contenu** visite (produit, article, page, auteur,
  categorie, archive, 404, accueil...) pour savoir *quoi* les plateformes
  consomment.
- **Distinction des fichiers techniques** : les requetes vers des assets
  (CSS, JS, images, polices, medias) sont marquees `is_asset` et **exclues par
  defaut** des statistiques, pour ne montrer que le contenu pertinent. Une
  bascule « Contenu / Tout » les reintegre.
- **Tableau de bord admin** : statistiques 24 h / 7 j / 30 j / total,
  histogramme, activite par famille et par plateforme, top URLs paginoes,
  visibilite par type de contenu, vues de detail par URL et par source,
  export CSV (filtres actifs preserves, BOM UTF-8 compatible Excel),
  purge par URL ou globale.
- **Propagation des filtres** : periode, source, finalite, famille et bascule
  assets se propagent vers les vues de detail et l'export. Le lien Retour
  revient au tableau de bord dans le meme etat.
- **Verification IP** : les visites de Google, OpenAI, Perplexity sont
  verifiees contre les plages CIDR officielles (badge « IP verifiee » ou
  « usurpation probable »). Mise a jour hebdomadaire automatique.
- **Indicateur de stockage** : ligne discrete en bas du tableau de bord
  (taille en octets + nombre de visites enregistrees).

## Installation

1. Copier le dossier `ai-visit-tracker/` dans `wp-content/plugins/`.
2. Activer « AI Visit Tracker » dans l'admin WordPress.
3. La table `{prefix}aivt_visits` est creee automatiquement a l'activation.
4. Consulter les donnees dans **Visibilite IA** (menu de niveau 1).

## Détails techniques

| Élément              | Valeur                                            |
|----------------------|---------------------------------------------------|
| Table custom         | `{wpdb->prefix}aivt_visits`                       |
| Option de version DB | `aivt_db_version`                                 |
| Page admin (slug)    | `ai-visit-tracker` (menu de niveau 1)             |
| Capability requise   | `manage_options`                                  |
| Préfixe code         | classe `AIVT_Tracker`, constantes `AIVT_*`        |
| PHP / WP minimum     | PHP 7.4 / WordPress 5.6                            |

- **WooCommerce facultatif** : la détection des types `product`,
  `product_category` et `shop_archive` s'active automatiquement si WooCommerce
  est présent ; sinon ces tests retournent simplement `false`, sans erreur.
- **Derrière Cloudflare** : l'IP réelle est lue depuis `CF-Connecting-IP`
  lorsqu'elle est disponible, avec repli sur `REMOTE_ADDR`.
- **Cache full-page** : les bots ne sont généralement pas servis depuis le
  cache de page, donc leurs requêtes atteignent bien PHP. Sur un site très
  caché, vérifier que les requêtes bots passent par PHP.

## Mises a jour

Les mises a jour sont gerees automatiquement par WordPress :

- **Automatiques par defaut** : chaque nouvelle version publiee sur le repo
  de releases est installee automatiquement sur les sites utilisant ce plugin
  (colonne « Mises a jour automatiques : Activees » dans la liste des extensions).
- **Verification manuelle** : dans la liste des extensions, cliquer le lien
  « Verifier les mises a jour » pour forcer une verification immediate et
  afficher une notice de resultat.

Les mises a jour proviennent du repo public d'artefacts :
https://github.com/CS-Digital-Suisse/ai-visit-tracker-releases

## RGPD

Le plugin stocke **IP** et **User-Agent** des crawlers. Base legale :
interet legitime (analyse de visibilite des plateformes). Pensez a mentionner
ce traitement dans la politique de confidentialite du site. La purge (par URL
ou globale) est disponible depuis la page d'admin.

## Perimetre des plateformes

Seules les plateformes utilisees par des utilisateurs finaux sont incluses :
IA, moteurs de recherche grand public, reseaux sociaux et messageries. Les
outils SEO (Ahrefs, Semrush, Screaming Frog...), les scrapers d'infrastructure
et les robots de monitoring ne sont **jamais** ajoutes. Decision ferme du
proprietaire (juin 2026).

## Origine

Extrait et generalise depuis le tracker IA du theme « Une Autre Voix »
(classe `UAV_AI_Tracker`). Le comportement est identique ; seuls les libelles
de type de contenu ont ete rendus generiques et les types propres au site
d'origine retires.
