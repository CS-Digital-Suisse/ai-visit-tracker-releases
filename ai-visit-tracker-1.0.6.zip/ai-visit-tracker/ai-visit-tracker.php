<?php
/**
 * Plugin Name:       AI Visit Tracker
 * Plugin URI:        https://csdigital.ch/
 * Description:       Suivi des crawlers IA (GPTBot, ClaudeBot, PerplexityBot, Google-Extended...) via detection User-Agent. Tableau de bord « Visibilite IA » (menu de niveau 1) : sources, top URLs, visibilite par type de contenu, histogramme. Aucune dependance, autonome et reutilisable.
 * Version:           1.0.6
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            CS Digital
 * Author URI:        https://csdigital.ch/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-visit-tracker
 * Update URI:        https://github.com/CS-Digital-Suisse/ai-visit-tracker-releases
 *
 * @package AI_Visit_Tracker
 *
 * @version 1.0.6
 *
 * @changelog
 * 1.0.6 : Image d'extension pour l'UI des mises a jour WordPress (assets/img/icon.svg,
 *          badge violet, cle 'icons' dans inject_update_info). Retour de l'icone
 *          de menu simple (SVG CPU gris #a7aaad, identique 1.0.4).
 *
 * 1.0.5 : Icone de menu : badge violet de la marque (degrade #6366f1 -> #8b5cf6,
 *          coins arrondis, motif CPU blanc centre) a la place du CPU gris.
 *
 * 1.0.4 : Correction de la verification manuelle : delete_site_transient
 *          avant wp_update_plugins() contourne le throttle 12 h de WP et
 *          affiche la banniere native « Mettre a jour maintenant ». Auto-update
 *          inscrit dans l'option native auto_update_plugins (via
 *          maybe_optin_auto_update) pour que la colonne UI reflète l'etat
 *          reel et affiche le decompte avant la prochaine mise a jour planifiee.
 *
 * 1.0.3 : Accent restaure dans le libelle du menu (« Visibilité IA »).
 *
 * 1.0.2 : Page d'admin passee en menu de niveau 1 (entree « Visibilite IA »)
 *          au lieu du sous-menu Outils. Hook toplevel_page_, URLs admin.php.
 *
 * 1.0.1 : Updater distant natif WordPress. Lecture du manifest latest.json
 *          depuis le repo public GitHub (transient 12 h, sentinelle 1 h en
 *          cas d'echec). Injection dans pre_set_site_transient_update_plugins,
 *          auto-update active par defaut, lien « Verifier les mises a jour »
 *          dans la liste des extensions, notice admin native apres verification.
 *          Update URI: dans l'entete du plugin (WP 5.8+). DB_VERSION inchangee.
 *
 * 1.0.0 : Premiere version stable. Plugin autonome de suivi des crawlers IA,
 *          généralisé depuis le tracker du thème « Une Autre Voix » et rendu
 *          non spécifique à un site (labels de contenu génériques, WooCommerce
 *          facultatif). Table custom {prefix}aivt_visits, page admin
 *          « Visibilite IA » avec interface moderne : topbar, cartes KPI
 *          animées, graphique d'activité, classements à barres par moteur d'IA
 *          et par type de contenu, table d'URLs custom, vues détail dédiées
 *          (URL, source, type de contenu) à en-tête sombre. Design system CSS
 *          autonome + JS vanilla (count-up, lignes cliquables), zéro dépendance.
 *          Distinction des fichiers techniques (assets CSS/JS/images/polices/
 *          médias) via la colonne is_asset : exclus par défaut des statistiques,
 *          réintégrables via une bascule, catégorie dédiée consultable.
 *          Finalité (entraînement / indexation / fetch utilisateur / agent)
 *          comme dimension à part entière : panneau, filtre, page dédiée et
 *          ventilation dans les vues détail ; faceting source x finalité.
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AIVT_VERSION', '1.0.6' );
define( 'AIVT_PLUGIN_FILE', __FILE__ );
define( 'AIVT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIVT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once AIVT_PLUGIN_DIR . 'includes/class-ai-visit-tracker.php';

/**
 * Crée / met à jour le schéma de la table à l'activation du plugin.
 * Planifie aussi le cron de rafraichissement des plages IP si absent.
 *
 * maybe_install_table() est idempotent (compare la version stockée), donc
 * sûr à rappeler. Le hook 'init' du tracker assure aussi la migration sur
 * les sites où le plugin serait mis à jour sans réactivation.
 *
 * @return void
 */
function aivt_activate() {
	AIVT_Tracker::get_instance()->maybe_install_table();
	if ( ! wp_next_scheduled( 'aivt_refresh_ip_ranges' ) ) {
		wp_schedule_event( time(), 'weekly', 'aivt_refresh_ip_ranges' );
	}
}
register_activation_hook( __FILE__, 'aivt_activate' );

/**
 * Déplanifie le cron de rafraichissement des plages IP à la désactivation.
 *
 * @return void
 */
function aivt_deactivate() {
	$timestamp = wp_next_scheduled( 'aivt_refresh_ip_ranges' );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'aivt_refresh_ip_ranges' );
	}
}
register_deactivation_hook( __FILE__, 'aivt_deactivate' );

/**
 * Initialise le tracker (Singleton). Le constructeur enregistre tous les
 * hooks (capture, page admin, purge, assets).
 *
 * @return void
 */
function aivt_bootstrap() {
	AIVT_Tracker::get_instance();
}
add_action( 'plugins_loaded', 'aivt_bootstrap' );
