/**
 * AI Visit Tracker : Interactions d'administration
 *
 * Vanilla ES5/ES6, aucune dépendance (pas de jQuery). Progressive
 * enhancement : tout reste fonctionnel si le script ne se charge pas.
 *
 *  - Count-up animé des valeurs KPI (data-count).
 *  - Lignes de table cliquables (data-href) sans casser les vrais liens.
 *
 * @package  AI_Visit_Tracker
 * @version  1.0.0
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn );
		}
	}

	/**
	 * Anime un compteur de 0 jusqu'à sa valeur cible, puis restaure
	 * la chaîne formatée d'origine (qui respecte la locale WordPress).
	 *
	 * @param {HTMLElement} el Élément .aivt-kpi-value[data-count].
	 */
	function countUp( el ) {
		var target = parseInt( el.getAttribute( 'data-count' ), 10 ) || 0;
		var original = el.textContent;
		if ( target <= 0 ) {
			return;
		}
		var duration = 900;
		var startTs = null;

		function frame( ts ) {
			if ( startTs === null ) {
				startTs = ts;
			}
			var progress = Math.min( ( ts - startTs ) / duration, 1 );
			var eased = 1 - Math.pow( 1 - progress, 3 );
			el.textContent = Math.round( target * eased ).toLocaleString();
			if ( progress < 1 ) {
				window.requestAnimationFrame( frame );
			} else {
				el.textContent = original;
			}
		}
		window.requestAnimationFrame( frame );
	}

	ready( function () {
		var reduce = window.matchMedia &&
			window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		if ( ! reduce && window.requestAnimationFrame ) {
			var values = document.querySelectorAll( '.aivt-kpi-value[data-count]' );
			Array.prototype.forEach.call( values, countUp );
		}

		var rows = document.querySelectorAll( '.aivt-table tr[data-href]' );
		Array.prototype.forEach.call( rows, function ( tr ) {
			tr.addEventListener( 'click', function ( e ) {
				// Laisser les vrais liens (et le clic milieu / modificateurs) agir.
				if ( e.target.closest( 'a' ) || e.metaKey || e.ctrlKey || e.button !== 0 ) {
					return;
				}
				window.location.href = tr.getAttribute( 'data-href' );
			} );
		} );
	} );
}() );
