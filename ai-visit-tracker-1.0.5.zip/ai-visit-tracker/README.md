# AI Visit Tracker

Plugin WordPress autonome qui journalise les visites des **crawlers IA**
(GPTBot, ClaudeBot, PerplexityBot, Google-Extended, Bytespider, CCBot…) par
détection du *User-Agent*, et fournit un tableau de bord d'analyse dans
**Visibilite IA** (menu de niveau 1).

Sans dépendance, sans librairie, sans réglage : on active, ça enregistre.
Conçu pour être réutilisable sur n'importe quel site WordPress.

---

## Ce que le plugin fait

- **Capture serveur** sur `template_redirect` (priorité 999) : chaque requête
  `GET`/`HEAD` dont le User-Agent correspond à un bot IA connu est enregistrée.
  Les visites humaines / non-IA **ne sont pas** loggées (table focalisée).
- **~30 bots reconnus**, classés par source (OpenAI, Anthropic, Google,
  Perplexity, Mistral, Meta, Apple, Microsoft, ByteDance, Amazon, DuckDuckGo,
  Cohere, You.com, Common Crawl) et par finalité (entraînement, indexation,
  fetch utilisateur, agent, publicité, service technique).
- **Finalité comme dimension à part entière** : panneau de répartition,
  filtre (menu déroulant) qui découpe tout le tableau de bord, page dédiée par
  finalité, et ventilation dans les vues détail (source, contenu, URL). Source
  et finalité fonctionnent en « faceting » (chaque filtre découpe l'ensemble,
  sauf son propre panneau).
- **Détection du type de contenu** visité (produit, article, page, auteur,
  catégorie, archive, 404, accueil…) pour savoir *quoi* les IA consomment.
- **Distinction des fichiers techniques** : les requêtes vers des assets
  (CSS, JS, images, polices, médias) sont marquées `is_asset` et **exclues par
  défaut** des statistiques, pour ne montrer que le contenu pertinent. Une
  bascule « Contenu / Tout » les réintègre, et une catégorie dédiée « Fichiers
  techniques » reste consultable (page de détail propre). `.xml`, `.txt`,
  `.pdf`, `.json` restent du contenu (intérêt SEO : sitemaps, robots, llms.txt).
- **Tableau de bord admin** : statistiques 24 h / 7 j / 30 j / total,
  histogramme, activité par **Plateforme**, top URLs paginées, visibilité par
  type de contenu, vues de détail par URL et par source, export CSV (filtres
  actifs preserves, BOM UTF-8 compatible Excel), purge par URL ou globale.
- **Propagation des filtres** : periode, source, finalite et bascule assets
  se propagent vers les vues de detail. Le lien Retour revient au tableau
  de bord dans le meme etat. Les compteurs des details correspondent exactement
  aux compteurs cliques sur le tableau de bord.
- **Verification IP** : les visites de Google, OpenAI, Perplexity sont verifiees
  contre les plages CIDR officielles (badge « IP verifiee » ou « usurpation
  probable »). Mise a jour hebdomadaire automatique (cron WordPress).
- **Indicateur de stockage** : ligne discrete en bas du tableau de bord
  (taille en octets + nombre de visites enregistrees).

## Installation

1. Copier le dossier `ai-visit-tracker/` dans `wp-content/plugins/`.
2. Activer « AI Visit Tracker » dans l'admin WordPress.
3. La table `{prefix}aivt_visits` est créée automatiquement à l'activation.
4. Consulter les données dans **Visibilite IA** (menu de niveau 1).

## Détails techniques

| Élément              | Valeur                                            |
|----------------------|---------------------------------------------------|
| Table custom         | `{wpdb->prefix}aivt_visits`                       |
| Option de version DB | `aivt_db_version`                                 |
| Page admin (slug)    | `ai-visit-tracker` (menu de niveau 1)             |
| Capability requise   | `manage_options`                                  |
| Préfixe code         | classe `AIVT_Tracker`, constantes `AIVT_*`        |
| PHP / WP minimum     | PHP 7.4 / WordPress 5.6                            |

- **WooCommerce facultatif** : la détection des types `product`,
  `product_category` et `shop_archive` s'active automatiquement si WooCommerce
  est présent ; sinon ces tests retournent simplement `false`, sans erreur.
- **Derrière Cloudflare** : l'IP réelle est lue depuis `CF-Connecting-IP`
  lorsqu'elle est disponible, avec repli sur `REMOTE_ADDR`.
- **Cache full-page** : les bots ne sont généralement pas servis depuis le
  cache de page, donc leurs requêtes atteignent bien PHP. Sur un site très
  caché, vérifier que les requêtes bots passent par PHP.

## Mises a jour

Les mises a jour sont gerees automatiquement par WordPress :

- **Automatiques par defaut** : chaque nouvelle version publiee sur le repo
  de releases est installee automatiquement sur les sites utilisant ce plugin
  (colonne « Mises a jour automatiques : Activees » dans la liste des extensions).
- **Verification manuelle** : dans la liste des extensions, cliquer le lien
  « Verifier les mises a jour » pour forcer une verification immediate et
  afficher une notice de resultat.

Les mises a jour proviennent du repo public d'artefacts :
https://github.com/CS-Digital-Suisse/ai-visit-tracker-releases

## RGPD

Le plugin stocke **IP** et **User-Agent** des crawlers. Base légale :
intérêt légitime (analyse SEO / visibilité). Pensez à mentionner ce
traitement dans la politique de confidentialité du site. La purge (par URL ou
globale) est disponible depuis la page d'admin.

## Origine

Extrait et généralisé depuis le tracker IA du thème « Une Autre Voix »
(classe `UAV_AI_Tracker`). Le comportement est identique ; seuls les libellés
de type de contenu ont été rendus génériques et les types propres au site
d'origine retirés.
